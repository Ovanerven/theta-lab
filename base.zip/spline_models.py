#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 30 12:00:02 2025

@author: bob-van-sluijs
"""
from __future__ import annotations
from utils import *
from pathlib import Path
import numpy as np
import torch
from torch import nn
import math
from typing import Mapping, Hashable, Sequence, Dict, List, Tuple
import torch.nn.functional as F
import torchcde
import torch._dynamo as dynamo
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import clip_grad_norm_


# def _step_grad(
#     m_prev:  torch.Tensor, p_prev:  torch.Tensor, pm_prev: torch.Tensor,
#     hTX:     torch.Tensor, hTL:     torch.Tensor, dna_cum: torch.Tensor,
#     dna_k:   torch.Tensor, dt_k:    torch.Tensor,
#     VTX_raw_k: torch.Tensor, VTX_max_k: torch.Tensor, kdm_k: torch.Tensor,
#     VTL_raw_k: torch.Tensor, VTL_max_k: torch.Tensor, kmt_k: torch.Tensor,
#     gate_rate: float, eps: float
# ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor,  # new m, p, pm
#            torch.Tensor, torch.Tensor, torch.Tensor]: # new hTX, hTL, dna_cum

#     lam     = torch.exp(-gate_rate * dt_k)

#     # gates -----------------------------------------------------------
#     hTX_inf = torch.sigmoid(VTX_raw_k)
#     hTL_inf = torch.sigmoid(VTL_raw_k)
#     hTX = hTX_inf + (hTX - hTX_inf) * lam
#     hTL = hTL_inf + (hTL - hTL_inf) * lam

#     VTX_eff = hTX * VTX_max_k
#     VTL_eff = hTL * VTL_max_k
#     dna_cum = dna_cum + dna_k

#     # mRNA ------------------------------------------------------------
#     m_inf  = (VTX_eff * dna_cum) / (kdm_k + eps)
#     exp_m  = torch.exp(-kdm_k * dt_k)
#     m_curr = (m_inf + (m_prev - m_inf) * exp_m).clamp_min_(0.)

#     # immature protein p ---------------------------------------------
#     eta    = torch.exp(-kmt_k * dt_k)
#     diff   = kdm_k - kmt_k
#     same   = diff.abs() < eps
#     int_m_conv_eq  = (m_inf * (1 - eta) / (kmt_k + eps) +
#                       (m_prev - m_inf) * dt_k * eta)
#     int_m_conv_gen = (m_inf * (1 - eta) / (kmt_k + eps) +
#                       (m_prev - m_inf) * (eta - exp_m) / (diff + eps))
#     int_m_conv = torch.where(same, int_m_conv_eq, int_m_conv_gen)

#     p_curr = (p_prev * eta + VTL_eff * int_m_conv).clamp_min_(0.)

#     # mature protein p* ----------------------------------------------
#     int_m_total = m_inf * dt_k + (m_prev - m_inf) / (kdm_k + eps) * (1 - exp_m)
#     pm_curr = (pm_prev + (p_prev - p_curr) + VTL_eff * int_m_total).clamp_min_(0.)

#     return m_curr, p_curr, pm_curr, hTX, hTL, dna_cum

# ###############################################################################
# # STEP B – forward-only version (Autograd OFF)
# ###############################################################################
# def _step_nograd(   # identical math, but no autograd ops are recorded
#     m_prev:  torch.Tensor, p_prev:  torch.Tensor, pm_prev: torch.Tensor,
#     hTX:     torch.Tensor, hTL:     torch.Tensor, dna_cum: torch.Tensor,
#     dna_k:   torch.Tensor, dt_k:    torch.Tensor,
#     VTX_raw_k: torch.Tensor, VTX_max_k: torch.Tensor, kdm_k: torch.Tensor,
#     VTL_raw_k: torch.Tensor, VTL_max_k: torch.Tensor, kmt_k: torch.Tensor,
#     gate_rate: float, eps: float
# ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor,
#            torch.Tensor, torch.Tensor, torch.Tensor]:

#     with torch.no_grad():                       # prevents tape recording
#         lam     = torch.exp(-gate_rate * dt_k)
#         hTX_inf = torch.sigmoid(VTX_raw_k)
#         hTL_inf = torch.sigmoid(VTL_raw_k)
#         hTX = hTX_inf + (hTX - hTX_inf) * lam
#         hTL = hTL_inf + (hTL - hTL_inf) * lam

#         VTX_eff = hTX * VTX_max_k
#         VTL_eff = hTL * VTL_max_k
#         dna_cum = dna_cum + dna_k

#         m_inf  = (VTX_eff * dna_cum) / (kdm_k + eps)
#         exp_m  = torch.exp(-kdm_k * dt_k)
#         m_curr = (m_inf + (m_prev - m_inf) * exp_m).clamp_min_(0.)

#         eta    = torch.exp(-kmt_k * dt_k)
#         diff   = kdm_k - kmt_k
#         same   = diff.abs() < eps
#         int_m_conv_eq  = (m_inf * (1 - eta) / (kmt_k + eps) +
#                           (m_prev - m_inf) * dt_k * eta)
#         int_m_conv_gen = (m_inf * (1 - eta) / (kmt_k + eps) +
#                           (m_prev - m_inf) * (eta - exp_m) / (diff + eps))
#         int_m_conv = torch.where(same, int_m_conv_eq, int_m_conv_gen)

#         p_curr = (p_prev * eta + VTL_eff * int_m_conv).clamp_min_(0.)

#         int_m_total = m_inf * dt_k + (m_prev - m_inf) / (kdm_k + eps) * (1 - exp_m)
#         pm_curr = (pm_prev + (p_prev - p_curr) + VTL_eff * int_m_total).clamp_min_(0.)

#         return m_curr, p_curr, pm_curr, hTX, hTL, dna_cum


# # ---- compile once; caches to ~/.torch_inductor_cache if enabled ----------
# _step_grad   = torch.compile(_step_grad,   mode="max-autotune")
# _step_nograd = torch.compile(_step_nograd, mode="max-autotune")
# print('Function compilation successfull')

# @torch.jit.script
# def integrate_vectors_analytical(
#     x0:        torch.Tensor,          # (B,5)
#     dna:       torch.Tensor,          # (B,K,1)
#     dt:        torch.Tensor,          # (B,K)
#     VTX_raw:   torch.Tensor,          # (B,K,1)
#     VTX_max:   torch.Tensor,          # (B,K,1)
#     kdm:       torch.Tensor,          # (B,K,1)
#     VTL_raw:   torch.Tensor,          # (B,K,1)
#     VTL_max:   torch.Tensor,          # (B,K,1)
#     kmt:       torch.Tensor,          # (B,K,1),
#     gate_rate : float = 10.0,
#     GRAD_PERIOD: int = 2,            # keep-grad every N steps
#     eps: float = 1e-9
# ) -> Tuple[torch.Tensor, torch.Tensor]:

#     B, K, _ = dna.shape
#     m_out  = torch.empty((B, K, 1), device=x0.device)
#     p_out  = torch.empty_like(m_out)
#     pm_out = torch.empty_like(m_out)
#     hT_out = torch.empty_like(m_out)
#     hL_out = torch.empty_like(m_out)

#     # rolling state
#     m_prev, p_prev, pm_prev = x0[:, 0:1], x0[:, 1:2], x0[:, 2:3]
#     hTX = x0[:, 3:4].clamp(0., 1.)
#     hTL = x0[:, 4:5].clamp(0., 1.)
#     dna_cum = dna.new_zeros((B, 1))

#     for k in range(K):

#         if k%GRAD_PERIOD == 0:
#             (m_prev, p_prev, pm_prev,hTX, hTL, dna_cum) = _step_grad(
#                 m_prev, p_prev, pm_prev,
#                 hTX, hTL, dna_cum,
#                 dna[:, k], dt[:, k:k+1],
#                 VTX_raw[:, k], VTX_max[:, k], kdm[:, k],
#                 VTL_raw[:, k], VTL_max[:, k], kmt[:, k],
#                 gate_rate, eps
#             )
#         else:
#             (m_prev, p_prev, pm_prev,hTX, hTL, dna_cum) = _step_nograd(
#                 m_prev, p_prev, pm_prev,
#                 hTX, hTL, dna_cum,
#                 dna[:, k], dt[:, k:k+1],
#                 VTX_raw[:, k], VTX_max[:, k], kdm[:, k],
#                 VTL_raw[:, k], VTL_max[:, k], kmt[:, k],
#                 gate_rate, eps
#             )

#         # save
#         m_out[:, k], p_out[:, k], pm_out[:, k] = m_prev, p_prev, pm_prev
#         hT_out[:, k], hL_out[:, k] = hTX, hTL

#         # detach after no-grad step so future grads don't cross it
#         if k % GRAD_PERIOD != 0:
#             m_prev  = m_prev.detach()
#             p_prev  = p_prev.detach()
#             pm_prev = pm_prev.detach()
#             hTX = hTX.detach()
#             hTL = hTL.detach()
#             dna_cum = dna_cum.detach()

#     out    = torch.cat((m_out, p_out, pm_out), dim=2)
#     params = torch.cat((VTX_max, hT_out, kdm, VTL_max, hL_out, kmt), dim=2)
#     return out, params

# ----------------------------------------------------------------------
# helpers --------------------------------------------------------------
# def gamma(raw: torch.Tensor, lo: float, hi: float) -> torch.Tensor:
#     """Log-scaled bounded exponential mapping."""
#     return torch.exp(torch.log(torch.tensor(lo)) +
#                      (math.log(hi) - math.log(lo)) * torch.sigmoid(raw))


def gamma(raw: torch.Tensor, lo: float, hi: float, tau: float = 2.3, cap: int = 50) -> torch.Tensor:
    # map R → (0,1) with gentler slope
    s = torch.sigmoid(raw / tau)
    log_lo = math.log(lo); log_hi = math.log(hi)
    return torch.exp(log_lo + (log_hi - log_lo) * s)

def build_x0_ext_on(x0: torch.Tensor) -> torch.Tensor:
    """
    Append two gate states initialised to 1 (ON).

    Returns
    -------
    x0_ext : (B, 5)  [m0, p0, p*0, hTX0, hTL0]
    """
    ones = torch.ones_like(x0[:, :1])        # (B,1)  filled with 1
    x0_ext = torch.cat((x0, ones, ones), dim=1)
    return x0_ext

###############################################################################
# Analytic IVTT integrator with Gates Rh and Rl directly learned from data
###############################################################################
#
#   dm/dt   = Rh · VTX_max · [DNA]  - k_dm  · m
#   dp/dt   = Rl · VTL_max · m       - k_mat · p
#   dpm/dt  = k_mat · p
#
# γ-bounded ranges are already applied outside this routine.
###############################################################################


@torch.jit.script
def integrate_vectors_analytical(
    x0: Tensor,             # (B,5)  m0 p0 p*0  hTX0 hTL0
    dna: Tensor,             # (B,K,1)   ΔDNA
    dt: Tensor,             # (B,K)     Δt
    VTX_raw: Tensor,             # (B,K,1)   gate logits
    VTX_max: Tensor,             # (B,K,1)
    kdm: Tensor,             # (B,K,1)
    VTL_raw: Tensor,             # (B,K,1)   gate logits
    VTL_max: Tensor,             # (B,K,1)
    kmt: Tensor,             # (B,K,1),
    gate_rate: float = 10.0        # relaxation speed κ  (1/min)
) -> Tuple[Tensor, Tensor]:
    """
    Five-state IVTT with continuous ON/OFF gates.

        ḣ_TX = κ (σ(raw_TX) − h_TX)
        VTX   = h_TX · VTX_max

        ḣ_TL = κ (σ(raw_TL) − h_TL)
        VTL   = hturn ((p > 0.5).float() - p).detach() + p    # STE mask
_TL · VTL_max
    """
    eps: float = 1e-9
    B, K, _ = dna.shape

    # buffers ----------------------------------------------------------
    m_out = torch.empty((B, K, 1), device=x0.device)
    p_out = torch.empty_like(m_out)
    pm_out = torch.empty_like(m_out)
    hT_out = torch.empty_like(m_out)
    hL_out = torch.empty_like(m_out)

    # init -------------------------------------------------------------
    m_prev = x0[:, 0:1]
    p_prev = x0[:, 1:2]
    pm_prev = x0[:, 2:3]
    hTX = x0[:, 3:4].clamp(0., 1.)
    hTL = x0[:, 4:5].clamp(0., 1.)
    dna_cum = dna.new_zeros((B, 1))

    for k in range(K):
        dt_k = dt[:, k:k+1]                     # (B,1)
        lam = torch.exp(-gate_rate * dt_k)     # e^{-κΔt}

        # -------- update gates analytically ---------------------------
        hTX_inf = torch.sigmoid(VTX_raw[:, k])     # desired level
        hTL_inf = torch.sigmoid(VTL_raw[:, k])

        hTX = hTX_inf + (hTX - hTX_inf) * lam
        hTL = hTL_inf + (hTL - hTL_inf) * lam

        # -------- effective catalytic rates --------------------------
        VTX_eff = hTX * VTX_max[:, k]
        VTL_eff = hTL * VTL_max[:, k]

        # -------- DNA pool -------------------------------------------
        dna_cum = dna_cum + dna[:, k]

        # -------- mRNA -----------------------------------------------
        kdm_k = kdm[:, k]
        m_inf = (VTX_eff * dna_cum) / (kdm_k + eps)
        exp_m = torch.exp(-kdm_k * dt_k)
        m_curr = m_inf + (m_prev - m_inf) * exp_m
        m_curr = m_curr.clamp_min(0.)

        # -------- ∫ m e^{-kmt(t-τ)} dτ for immature protein p -----------
        kmt_k = kmt[:, k]
        eta = torch.exp(-kmt_k * dt_k)
        diff = kdm_k - kmt_k
        same = diff.abs() < eps

        # This integral (int_m_conv) correctly solves for p_curr
        int_m_conv_eq = (m_inf * (1 - eta) / (kmt_k + eps) +
                         (m_prev - m_inf) * dt_k * eta)
        int_m_conv_gen = (m_inf * (1 - eta) / (kmt_k + eps) +
                          (m_prev - m_inf) *
                          (eta - exp_m) / (diff + eps))
        int_m_conv = torch.where(same, int_m_conv_eq, int_m_conv_gen)

        # -------- Immature protein p ----------------------------------
        p_curr = p_prev * eta + VTL_eff * int_m_conv

        # -------- NEW: Integral of total mRNA for mature protein p* -----
        # This term calculates ∫m(τ)dτ from t_{k-1} to t_k, which represents
        # the total amount of mRNA available for translation during the step.
        int_m_total = m_inf * dt_k + \
            (m_prev - m_inf) / (kdm_k + eps) * (1 - exp_m)

        # -------- CHANGED: Mature protein p* update -------------------
        # The correct update rule derived from the conservation law d/dt(p+p*) = VTL*m.
        # It accounts for both maturation of old protein and synthesis of new protein.
        pm_curr = pm_prev + (p_prev - p_curr) + VTL_eff * int_m_total

        # positivity ---------------------------------------------------
        p_curr = p_curr.clamp_min(0.)
        pm_curr = pm_curr.clamp_min(0.)

        # store --------------------------------------------------------
        m_out[:, k], p_out[:, k], pm_out[:, k] = m_curr, p_curr, pm_curr
        hT_out[:, k], hL_out[:, k] = hTX, hTL

        # roll ---------------------------------------------------------
        m_prev, p_prev, pm_prev = m_curr, p_curr, pm_curr

    out = torch.cat((m_out, p_out, pm_out), dim=2)
    params = torch.cat((VTX_max, hT_out, kdm, VTL_max, hL_out, kmt), dim=2)
    return out, params


###############################################################################
# Analytic IVTT integrator with single resource decay
###############################################################################
#
#   dR/dt   = -λ · R                 ,   R(0) = 1
#   dm/dt   = R · VTX_max · [DNA]  - k_dm  · m
#   dp/dt   = R · VTL_max · m       - k_mat · p
#   dpm/dt  = k_mat · p
#
# γ-bounded ranges are already applied outside this routine.
###############################################################################

@torch.jit.script
def integrate_vectors_analytical_R(
        x0: torch.Tensor,  # (B,4)  m0 p0 p*0 R0  (R0 = 1)
        dna: torch.Tensor,  # (B,K,1)
        dt: torch.Tensor,  # (B,K)
        VTX_max: torch.Tensor,  # (B,K,1)
        kdm: torch.Tensor,  # (B,K,1)
        VTL_max: torch.Tensor,  # (B,K,1)
        kmt: torch.Tensor,  # (B,K,1)
        lam: torch.Tensor   # (B,1)   positive decay rate λ
) -> Tuple[torch.Tensor, torch.Tensor]:
    eps: float = 1e-9
    B, K, _ = dna.shape

    # ---------- output buffers ----------
    m_out = torch.empty((B, K, 1), device=x0.device)
    p_out = torch.empty_like(m_out)
    pm_out = torch.empty_like(m_out)
    R_out = torch.empty_like(m_out)
    
    dna_cum_total = torch.cumsum(dna, dim=1)[:, -1, :]  # (B,1) — total DNA at last timepoint
    # ------------ DNA tensor ------------
    # (B,1) — total DNA at last timepoint
    # ---------- initial state -----------
    m_prev = x0[:, 0:1]                     # (B,1)
    p_prev = x0[:, 1:2]
    pm_prev = x0[:, 2:3]
    R_prev = x0[:, 3:4].clamp_min(eps)      # starts at 1
    dna_cum = dna.new_zeros((B, 1))

    for k in range(K):
        dt_k = dt[:, k:k+1]                  # (B,1)

        # ---- resource decay  R_k = R_{k-1} e^{-λ Δt} ----
        rho = torch.exp(-lam[:, k] * dt_k)       # (B,1)
        R_curr = R_prev * rho

        # ---- effective catalytic rates ----
        VTX_eff = R_curr * VTX_max[:, k]     # (B,1)
        VTL_eff = R_curr * VTL_max[:, k]

        # ---- DNA pool ----------------------
        dna_cum = dna_cum_total    # cumulative μM DNA

        # ---- mRNA --------------------------
        kdm_k = kdm[:, k]
        m_inf = (VTX_eff * dna_cum) / (kdm_k + eps)
        exp_m = torch.exp(-kdm_k * dt_k)
        m_curr = m_inf + (m_prev - m_inf) * exp_m
        m_curr = m_curr.clamp_min(0.)

        # ---- ∫ m e^{-k_mat(t-τ)} dτ --------
        kmt_k = kmt[:, k]
        eta = torch.exp(-kmt_k * dt_k)
        diff = kdm_k - kmt_k
        same = diff.abs() < eps

        int_m_eq = (m_inf * (1 - eta) / (kmt_k + eps) +
                    (m_prev - m_inf) * dt_k * eta)
        int_m_gen = (m_inf * (1 - eta) / (kmt_k + eps) +
                     (m_prev - m_inf) * (eta - exp_m) / (diff + eps))
        int_m_conv = torch.where(same, int_m_eq, int_m_gen)

        # ---- immature protein p ------------
        p_curr = p_prev * eta + VTL_eff * int_m_conv

        # ---- ∫ m dτ for mature protein -----
        int_m_total = (m_inf * dt_k +
                       (m_prev - m_inf) / (kdm_k + eps) * (1 - exp_m))

        pm_curr = pm_prev + (p_prev - p_curr) + VTL_eff * int_m_total

        # ---- positivity & store ------------
        p_curr = p_curr.clamp_min(0.)
        pm_curr = pm_curr.clamp_min(0.)

        m_out[:, k], p_out[:, k], pm_out[:, k] = m_curr, p_curr, pm_curr
        R_out[:, k] = R_curr

        # ---- roll state --------------------
        m_prev, p_prev, pm_prev, R_prev = m_curr, p_curr, pm_curr, R_curr

    out = torch.cat((m_out, p_out, pm_out), dim=2)           # (B,K,3)
    params = torch.cat((VTX_max, kdm, VTL_max, kmt, R_out, lam), dim=2)
    return out, params


@torch.jit.script
def integrate_vectors_analytical_R_mRNA_maturation(
        x0: torch.Tensor,      # (B,5)  [m0, mm0, p0, p*0, R0]
        dna: torch.Tensor,     # (B,K,1)
        dt: torch.Tensor,      # (B,K)
        VTX_max: torch.Tensor, # (B,K,1)
        kdm: torch.Tensor,     # (B,K,1)
        VTL_max: torch.Tensor, # (B,K,1)
        kmt: torch.Tensor,     # (B,K,1)   protein maturation rate
        kmatm: torch.Tensor,   # (B,K,1)   mRNA maturation rate (m -> mm)
        lam: torch.Tensor      # (B,K,1)   resource decay λ (expand beforehand if per-seq)
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Analytic IVTT with single resource decay and mRNA maturation:

        dR/dt   = -λ R
        dm/dt   = S - (kdm + kmatm) m                 ,  S = R VTX_max [DNA]_cum
        dmm/dt  = kmatm m - kdm mm
        dp/dt   = (R VTL_max) (m + mm) - kmt p
        dpm/dt  = kmt p

    Assumes parameters are frozen on each [t_{k-1}, t_k) and uses the end-of-step
    R_k = R_{k-1} exp(-λ Δt) as the effective constant within the step.

    Returns:
      out    : (B,K,4)  channels [m, mm, p, p*]
      params : (B,K,7)  [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    eps: float = 1e-9
    B, K, _ = dna.shape

    # ---------- output buffers ----------
    m_out  = torch.empty((B, K, 1), device=x0.device, dtype=x0.dtype)
    mm_out = torch.empty_like(m_out)
    p_out  = torch.empty_like(m_out)
    pm_out = torch.empty_like(m_out)
    R_out  = torch.empty_like(m_out)

    # total DNA per sequence (constant within each step, like your simple solver)
    dna_cum_total = torch.cumsum(dna, dim=1)[:, -1, :]  # (B,1)

    # ---------- initial state -----------
    m_prev   = x0[:, 0:1]              # (B,1)
    p_prev   = x0[:, 1:2]              # (B,1)
    pm_prev  = x0[:, 2:3]              # (B,1)
    R_prev   = x0[:, 3:4].clamp_min(eps)  # (B,1)
    mm_prev  = x0[:, 4:5]              # (B,1)

    # (Optional safety) allow lam given as (B,1) by expanding once
    if lam.size(1) == 1:
        lam = lam.expand(B, K, 1)

    for k in range(K):
        dt_k   = dt[:, k:k+1]          # (B,1)

        # ---- per-step params (B,1) ----
        lam_k  = lam[:,     k]         # (B,1)
        kdm_k  = kdm[:,     k]
        km_k   = kmatm[:,   k]
        kmt_k  = kmt[:,     k]
        VTX_k  = VTX_max[:, k]
        VTL_k  = VTL_max[:, k]

        # ---- resource decay  R_k = R_{k-1} e^{-λ Δt} ----
        rho    = torch.exp(-lam_k * dt_k)
        R_curr = R_prev * rho

        # ---- effective rates & source term ----
        VTX_eff = R_curr * VTX_k
        VTL_eff = R_curr * VTL_k
        S       = VTX_eff * dna_cum_total          # (B,1) constant in step

        # ---- m (immature mRNA): dm/dt = S - (kdm+km) m ----
        alpha  = (kdm_k + km_k).clamp_min(eps)
        m_inf  = S / alpha
        exp_a  = torch.exp(-alpha * dt_k)
        m_curr = m_inf + (m_prev - m_inf) * exp_a
        m_curr = m_curr.clamp_min(0.)

        # ---- mm (mature mRNA): dmm/dt = km m - kdm mm (closed form) ----
        exp_d  = torch.exp(-kdm_k * dt_k)          # e^{-kdm Δt}
        exp_mr = torch.exp(-km_k  * dt_k)          # e^{-km   Δt}
        term1  = mm_prev * exp_d
        term2  = m_inf * (km_k / (kdm_k + eps)) * (1. - exp_d)
        term3  = (m_prev - m_inf) * exp_d * (1. - exp_mr)
        mm_curr = term1 + term2 + term3
        mm_curr = mm_curr.clamp_min(0.)

        # ---- total M = m + mm (for protein) obeys dM/dt = S - kdm M ----
        M_prev = m_prev + mm_prev
        M_inf  = S / (kdm_k + eps)
        exp_M  = exp_d                           # e^{-kdm Δt}

        # ---- protein p: dp/dt = VTL_eff * M - kmt p ----
        eta    = torch.exp(-kmt_k * dt_k)        # e^{-kmt Δt}
        diff   = kdm_k - kmt_k
        same   = diff.abs() < 1e-6

        int_M_eq  = (M_inf * (1. - eta) / (kmt_k + eps)
                     + (M_prev - M_inf) * dt_k * eta)
        int_M_gen = (M_inf * (1. - eta) / (kmt_k + eps)
                     + (M_prev - M_inf) * (eta - exp_M) / (diff + eps))
        int_M_conv = torch.where(same, int_M_eq, int_M_gen)

        p_curr = p_prev * eta + VTL_eff * int_M_conv
        p_curr = p_curr.clamp_min(0.)

        # ---- mature protein p*: conservation d/dt(p+p*) = VTL_eff * M ----
        int_M_total = (M_inf * dt_k
                       + (M_prev - M_inf) / (kdm_k + eps) * (1. - exp_M))
        pm_curr = pm_prev + (p_prev - p_curr) + VTL_eff * int_M_total
        pm_curr = pm_curr.clamp_min(0.)

        # ---- store (same style as your simple solver) ----
        m_out[:,  k]  = m_curr
        mm_out[:, k]  = mm_curr
        p_out[:,  k]  = p_curr
        pm_out[:, k]  = pm_curr
        R_out[:,  k]  = R_curr

        # ---- roll ----
        m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

    out = torch.cat((mm_out, p_out, pm_out), dim=2)                      # (B,K,4)
    params = torch.cat((VTX_max, kdm, VTL_max, kmt, kmatm, R_out, lam), dim=2)  # (B,K,7)
    return out, params
                       
@torch.jit.script
def ivtt_step_mRNA_maturation(
    m_prev:  torch.Tensor,   # (B,1) immature m
    mm_prev: torch.Tensor,   # (B,1) mature mRNA (bright)
    p_prev:  torch.Tensor,   # (B,1) immature protein
    pm_prev: torch.Tensor,   # (B,1) mature protein
    R_prev:  torch.Tensor,   # (B,1)
    dt_k:    torch.Tensor,   # (B,1)
    dna_cum_total: torch.Tensor,  # (B,1) constant within step
    lam_k:   torch.Tensor,   # (B,1)
    VTXmax:  torch.Tensor,   # (B,1)
    kdm:     torch.Tensor,   # (B,1)
    VTLmax:  torch.Tensor,   # (B,1)
    kmt:     torch.Tensor,   # (B,1) protein maturation rate
    kmatm:   torch.Tensor,   # (B,1) mRNA maturation rate (m -> mm)
    eps: float = 1e-9
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    One analytic IVTT step with mRNA maturation.
    Returns: (m_curr, mm_curr, p_curr, pm_curr, R_curr), each (B,1).
    """
    # --- resource decay (use end-of-step as effective within step) ---
    rho    = torch.exp(-lam_k * dt_k)     # (B,1)
    R_curr = R_prev * rho

    # --- effective catalytic rates and source S ----------------------
    VTX_eff = R_curr * VTXmax
    VTL_eff = R_curr * VTLmax
    S       = VTX_eff * dna_cum_total     # (B,1), constant within step

    # --- m (immature) ------------------------------------------------
    alpha  = (kdm + kmatm).clamp_min(eps) # (B,1)
    m_inf  = S / alpha
    exp_a  = torch.exp(-alpha * dt_k)
    m_curr = torch.clamp_min(m_inf + (m_prev - m_inf) * exp_a, 0.0)

    # --- mm (matured mRNA) ------------------------------------------
    exp_d  = torch.exp(-kdm   * dt_k)     # e^{-kdm Δt}
    exp_mr = torch.exp(-kmatm * dt_k)     # e^{-kmatm Δt}
    term1  = mm_prev * exp_d
    term2  = m_inf * (kmatm / (kdm + eps)) * (1.0 - exp_d)
    term3  = (m_prev - m_inf) * exp_d * (1.0 - exp_mr)
    mm_curr = torch.clamp_min(term1 + term2 + term3, 0.0)

    # --- total mRNA M for protein formulas --------------------------
    M_prev = m_prev + mm_prev
    M_inf  = S / (kdm + eps)
    exp_M  = exp_d

    # --- protein p ---------------------------------------------------
    eta    = torch.exp(-kmt * dt_k)       # e^{-kmt Δt}
    delta  = (kdm - kmt)
    same   = torch.abs(delta) < 1e-6

    int_M_eq  = (M_inf * (1.0 - eta) / (kmt + eps)
                 + (M_prev - M_inf) * dt_k * eta)
    int_M_gen = (M_inf * (1.0 - eta) / (kmt + eps)
                 + (M_prev - M_inf) * (eta - exp_M) / (delta + eps))
    int_M_conv = torch.where(same, int_M_eq, int_M_gen)

    p_curr  = torch.clamp_min(p_prev * eta + VTL_eff * int_M_conv, 0.0)

    # --- mature protein p* (conservation) ---------------------------
    int_M_total = (M_inf * dt_k
                  + (M_prev - M_inf) / (kdm + eps) * (1.0 - exp_M))
    pm_curr = torch.clamp_min(pm_prev + (p_prev - p_curr) + VTL_eff * int_M_total, 0.0)

    return m_curr, mm_curr, p_curr, pm_curr, R_curr



@torch.jit.script
def ivtt_step_R_O_mRNA_maturation(
    m_prev:  torch.Tensor,   # (B,1)
    mm_prev: torch.Tensor,   # (B,1)
    p_prev:  torch.Tensor,   # (B,1)
    pm_prev: torch.Tensor,   # (B,1)
    R_prev:  torch.Tensor,   # (B,1)
    O_prev:  torch.Tensor,   # (B,1)
    dt_k:    torch.Tensor,   # (B,1)
    dna_cum_total: torch.Tensor,  # (B,1)
    lam_k:   torch.Tensor,   # (B,1)
    lam_O_k: torch.Tensor,   # (B,1)
    VTXmax:  torch.Tensor,   # (B,1)
    kdm:     torch.Tensor,   # (B,1)
    VTLmax:  torch.Tensor,   # (B,1)
    kmt:     torch.Tensor,   # (B,1)
    kmatm:   torch.Tensor,   # (B,1)
    eps: float = 1e-9
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    One analytic IVTT step with R decay, O decay, and mRNA maturation.

    Equations:
        dR/dt   = -lam R
        dO/dt   = -lam_O O
        dm/dt   = R VTXmax DNA - (kdm + kmatm) m
        dmm/dt  = kmatm m - kdm mm
        dp/dt   = R VTLmax (m + mm) - kmt p
        dpm/dt  = O kmt p

    Returns:
        m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
    """

    # --- resource / O decay, using end-of-step values as effective constants ---
    rho_R  = torch.exp(-lam_k * dt_k)
    rho_O  = torch.exp(-lam_O_k * dt_k)

    R_curr = R_prev * rho_R
    O_curr = O_prev * rho_O

    # --- effective catalytic rates and source S ----------------------
    VTX_eff = R_curr * VTXmax
    VTL_eff = R_curr * VTLmax
    O_eff   = O_curr

    S = VTX_eff * dna_cum_total

    # --- m immature mRNA ---------------------------------------------
    alpha  = (kdm + kmatm).clamp_min(eps)
    m_inf  = S / alpha
    exp_a  = torch.exp(-alpha * dt_k)

    m_curr = torch.clamp_min(
        m_inf + (m_prev - m_inf) * exp_a,
        0.0
    )

    # --- mm mature mRNA ----------------------------------------------
    exp_d  = torch.exp(-kdm * dt_k)
    exp_mr = torch.exp(-kmatm * dt_k)

    term1 = mm_prev * exp_d
    term2 = m_inf * (kmatm / (kdm + eps)) * (1.0 - exp_d)
    term3 = (m_prev - m_inf) * exp_d * (1.0 - exp_mr)

    mm_curr = torch.clamp_min(term1 + term2 + term3, 0.0)

    # --- total mRNA M = m + mm ---------------------------------------
    M_prev = m_prev + mm_prev
    M_inf  = S / (kdm + eps)
    exp_M  = exp_d

    # --- immature protein p ------------------------------------------
    eta   = torch.exp(-kmt * dt_k)
    delta = kdm - kmt
    same  = torch.abs(delta) < 1e-6

    int_M_eq = (
        M_inf * (1.0 - eta) / (kmt + eps)
        + (M_prev - M_inf) * dt_k * eta
    )

    int_M_gen = (
        M_inf * (1.0 - eta) / (kmt + eps)
        + (M_prev - M_inf) * (eta - exp_M) / (delta + eps)
    )

    int_M_conv = torch.where(same, int_M_eq, int_M_gen)

    p_curr = torch.clamp_min(
        p_prev * eta + VTL_eff * int_M_conv,
        0.0
    )

    # --- mature protein p*: dpm/dt = O_eff * kmt * p -----------------
    # Since dp/dt = VTL_eff*M - kmt*p:
    # kmt ∫p dt = VTL_eff∫Mdt - (p_curr - p_prev)
    int_M_total = (
        M_inf * dt_k
        + (M_prev - M_inf) / (kdm + eps) * (1.0 - exp_M)
    )

    pm_curr = torch.clamp_min(
        pm_prev + O_eff * (VTL_eff * int_M_total - (p_curr - p_prev)),
        0.0
    )

    return m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr

@torch.jit.script
def ivtt_step(
    m_prev: torch.Tensor,    # (B,1)
    p_prev: torch.Tensor,    # (B,1)
    pm_prev: torch.Tensor,   # (B,1)
    R_prev: torch.Tensor,    # (B,1)
    dt_k: torch.Tensor,      # (B,1)
    dna_cum_total: torch.Tensor,  # (B,1)  constant over k
    lam_k: torch.Tensor,     # (B,1)
    VTXmax: torch.Tensor,    # (B,1)
    kdm: torch.Tensor,       # (B,1)
    VTLmax: torch.Tensor,    # (B,1)
    kmt: torch.Tensor,       # (B,1)
    eps: float = 1e-9
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    One analytic time step of the IVTT model with resource decay R.
    Returns: (m_curr, p_curr, pm_curr, R_curr), each (B,1).
    """
    # resource decay
    rho    = torch.exp(-lam_k * dt_k)        # (B,1)
    R_curr = R_prev * rho

    # effective catalytic rates
    VTX_eff = R_curr * VTXmax
    VTL_eff = R_curr * VTLmax

    # mRNA
    m_inf  = (VTX_eff * dna_cum_total) / (kdm + eps)
    exp_m  = torch.exp(-kdm * dt_k)
    m_curr = m_inf + (m_prev - m_inf) * exp_m
    m_curr = torch.clamp_min(m_curr, 0.0)

    # immature protein p
    eta    = torch.exp(-kmt * dt_k)
    diff   = kdm - kmt
    same   = torch.abs(diff) < eps
    int_m_eq  = (m_inf * (1.0 - eta) / (kmt + eps)
                 + (m_prev - m_inf) * dt_k * eta)
    int_m_gen = (m_inf * (1.0 - eta) / (kmt + eps)
                 + (m_prev - m_inf) * (eta - exp_m) / (diff + eps))
    int_m_conv = torch.where(same, int_m_eq, int_m_gen)
    p_curr = p_prev * eta + VTL_eff * int_m_conv
    p_curr = torch.clamp_min(p_curr, 0.0)

    # mature protein p* (conservation)
    int_m_total = m_inf * dt_k + (m_prev - m_inf) / (kdm + eps) * (1.0 - exp_m)
    pm_curr = pm_prev + (p_prev - p_curr) + VTL_eff * int_m_total
    pm_curr = torch.clamp_min(pm_curr, 0.0)

    return m_curr, p_curr, pm_curr, R_curr


@torch.jit.script
def ivtt_step_mRNA_two_stage_protein(
    m_prev:  torch.Tensor,   # (B,1) immature mRNA
    mm_prev: torch.Tensor,   # (B,1) observed (mature) mRNA
    p_prev:  torch.Tensor,   # (B,1) immature protein
    pi_prev: torch.Tensor,   # (B,1) intermediate protein (new state)
    pm_prev: torch.Tensor,   # (B,1) observed (mature) protein
    R_prev:  torch.Tensor,   # (B,1) resource
    dt_k:    torch.Tensor,   # (B,1)
    dna_cum_total: torch.Tensor,  # (B,1) constant within step
    lam_k:   torch.Tensor,   # (B,1)
    VTXmax:  torch.Tensor,   # (B,1)
    kdm:     torch.Tensor,   # (B,1) mRNA decay
    VTLmax:  torch.Tensor,   # (B,1)
    kmt1:    torch.Tensor,   # (B,1) p -> p_i       (was kmt)
    kmt2:    torch.Tensor,   # (B,1) p_i -> p_m     (new time-dep param)
    kmatm:   torch.Tensor,   # (B,1) m -> mm
    eps: float = 1e-9
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    One analytic IVTT step with two-stage protein maturation.
    Returns: (m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr), each (B,1).
    """

    # ---------- resource decay ----------
    rho    = torch.exp(-lam_k * dt_k)
    R_curr = R_prev * rho

    # ---------- effective rates ----------
    VTX_eff = R_curr * VTXmax
    VTL_eff = R_curr * VTLmax
    S       = VTX_eff * dna_cum_total   # constant within step

    # ---------- m (immature)  dm/dt = S - (kdm + kmatm) m ----------
    alpha  = (kdm + kmatm).clamp_min(eps)
    m_inf  = S / alpha
    exp_a  = torch.exp(-alpha * dt_k)
    m_curr = torch.clamp_min(m_inf + (m_prev - m_inf) * exp_a, 0.0)

    # ---------- mm (observed mRNA) ----------
    exp_d  = torch.exp(-kdm   * dt_k)     # e^{-kdm Δt}
    exp_mr = torch.exp(-kmatm * dt_k)     # e^{-kmatm Δt}
    term1  = mm_prev * exp_d
    term2  = m_inf * (kmatm / (kdm + eps)) * (1.0 - exp_d)
    term3  = (m_prev - m_inf) * exp_d * (1.0 - exp_mr)
    mm_curr = torch.clamp_min(term1 + term2 + term3, 0.0)

    # ---------- total mRNA M for protein terms ----------
    M_prev = m_prev + mm_prev
    M_inf  = S / (kdm + eps)
    exp_M  = exp_d  # e^{-kdm Δt}

    # ---------- p (immature protein): dp/dt = VTL_eff M - kmt1 p ----------
    eta1   = torch.exp(-kmt1 * dt_k)     # e^{-kmt1 Δt}
    delta1 = (kdm - kmt1)
    same1  = torch.abs(delta1) < 1e-6

    # ∫_0^Δt M(τ) e^{-kmt1 (Δt-τ)} dτ  (your existing single-stage integral)
    int_M_eq_1  = (M_inf * (1.0 - eta1) / (kmt1 + eps)
                   + (M_prev - M_inf) * dt_k * eta1)
    int_M_gen_1 = (M_inf * (1.0 - eta1) / (kmt1 + eps)
                   + (M_prev - M_inf) * (eta1 - exp_M) / (delta1 + eps))
    I1 = torch.where(same1, int_M_eq_1, int_M_gen_1)

    p_curr  = torch.clamp_min(p_prev * eta1 + VTL_eff * I1, 0.0)

    # ---------- p_i (intermediate): dpi/dt = kmt1 p - kmt2 p_i ----------
    eta2   = torch.exp(-kmt2 * dt_k)     # e^{-kmt2 Δt}
    diff12 = (kmt1 - kmt2)
    same12 = torch.abs(diff12) < 1e-6

    # Initial p contribution to p_i (closed form)
    # J1 = kmt1 * p_prev * e^{-kmt2 Δt} * (1 - e^{-(kmt1-kmt2) Δt})/(kmt1 - kmt2)
    J1_gen = (kmt1 / (diff12 + eps)) * (eta2 - eta1) * p_prev
    # Equal-rate limit: J1 = k * dt * e^{-k dt} * p_prev
    J1_eq  = (kmt1 * dt_k * eta1) * p_prev
    J1     = torch.where(same12, J1_eq, J1_gen)

    # Input M contribution to p_i via two-stage kernel:
    # J2 = kmt1 * VTL_eff * [ I2 - I1 ] / (kmt1 - kmt2),
    # where I2 is the single-stage integral with kmt2
    delta2 = (kdm - kmt2)
    same2  = torch.abs(delta2) < 1e-6
    int_M_eq_2  = (M_inf * (1.0 - eta2) / (kmt2 + eps)
                   + (M_prev - M_inf) * dt_k * eta2)
    int_M_gen_2 = (M_inf * (1.0 - eta2) / (kmt2 + eps)
                   + (M_prev - M_inf) * (eta2 - exp_M) / (delta2 + eps))
    I2 = torch.where(same2, int_M_eq_2, int_M_gen_2)

    J2_gen = (kmt1 / (diff12 + eps)) * VTL_eff * (I2 - I1)

    # Equal-rate limit for J2: k * dI/dk at k=kmt1 (finite-diff fallback)
    # Small positive delta for numerical derivative:
    delta_k = torch.full_like(kmt1, 1e-6)
    k_plus  = (kmt1 + delta_k).clamp_min(eps)
    eta_plus = torch.exp(-k_plus * dt_k)
    delta_plus = (kdm - k_plus)
    same_plus  = torch.abs(delta_plus) < 1e-6
    int_M_eq_p = (M_inf * (1.0 - eta_plus) / (k_plus + eps)
                  + (M_prev - M_inf) * dt_k * eta_plus)
    int_M_gen_p= (M_inf * (1.0 - eta_plus) / (k_plus + eps)
                  + (M_prev - M_inf) * (eta_plus - exp_M) / (delta_plus + eps))
    I_plus = torch.where(same_plus, int_M_eq_p, int_M_gen_p)
    dI_dk  = (I_plus - I1) / (delta_k + eps)
    J2_eq  = kmt1 * VTL_eff * dI_dk

    J2 = torch.where(same12, J2_eq, J2_gen)

    pi_curr = torch.clamp_min(pi_prev * eta2 + J1 + J2, 0.0)

    # ---------- p_m (observed mature protein) via conservation ----------
    # Total protein increases by VTL_eff * ∫ M(τ) dτ
    int_M_total = (M_inf * dt_k
                   + (M_prev - M_inf) / (kdm + eps) * (1.0 - exp_M))
    pm_curr = torch.clamp_min(pm_prev + (p_prev + pi_prev - (p_curr + pi_curr)) + VTL_eff * int_M_total, 0.0)

    return m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr



@torch.jit.script
def integrate_vectors_analytical_R_O_mRNA_maturation(
        x0: torch.Tensor,       # (B,6) [m0, p0, p*0, R0, mm0, O0]
        dna: torch.Tensor,      # (B,K,1)
        dt: torch.Tensor,       # (B,K)
        VTX_max: torch.Tensor,  # (B,K,1)
        kdm: torch.Tensor,      # (B,K,1)
        VTL_max: torch.Tensor,  # (B,K,1)
        kmt: torch.Tensor,      # (B,K,1)
        kmatm: torch.Tensor,    # (B,K,1)
        lam: torch.Tensor,      # (B,K,1) or (B,1)
        lam_O: torch.Tensor     # (B,K,1) or (B,1)
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Analytic IVTT with resource decay R, output/resource factor O, and mRNA maturation:

        dR/dt   = -lam R
        dO/dt   = -lam_O O
        dm/dt   = R VTX_max DNA - (kdm + kmatm) m
        dmm/dt  = kmatm m - kdm mm
        dp/dt   = R VTL_max (m + mm) - kmt p
        dpm/dt  = O kmt p

    Parameters are frozen per step. R and O use end-of-step values as effective
    constants within each step.
    """
    eps: float = 1e-9
    B, K, _ = dna.shape

    m_out  = torch.empty((B, K, 1), device=x0.device, dtype=x0.dtype)
    mm_out = torch.empty_like(m_out)
    p_out  = torch.empty_like(m_out)
    pm_out = torch.empty_like(m_out)
    R_out  = torch.empty_like(m_out)
    O_out  = torch.empty_like(m_out)

    dna_cum_total = torch.cumsum(dna, dim=1)[:, -1, :]  # (B,1)

    m_prev  = x0[:, 0:1]
    p_prev  = x0[:, 1:2]
    pm_prev = x0[:, 2:3]
    R_prev  = x0[:, 3:4].clamp_min(eps)
    mm_prev = x0[:, 4:5]
    O_prev  = x0[:, 5:6].clamp_min(eps)

    if lam.size(1) == 1:
        lam = lam.expand(B, K, 1)

    if lam_O.size(1) == 1:
        lam_O = lam_O.expand(B, K, 1)

    for k in range(K):
        dt_k = dt[:, k:k+1]

        lam_k   = lam[:, k]
        lam_O_k = lam_O[:, k]

        kdm_k = kdm[:, k]
        km_k  = kmatm[:, k]
        kmt_k = kmt[:, k]
        VTX_k = VTX_max[:, k]
        VTL_k = VTL_max[:, k]

        # ---- R and O decay ----
        R_curr = R_prev * torch.exp(-lam_k * dt_k)
        O_curr = O_prev * torch.exp(-lam_O_k * dt_k)

        # ---- effective stepwise constants ----
        VTX_eff = R_curr * VTX_k
        VTL_eff = R_curr * VTL_k
        O_eff   = O_curr

        S = VTX_eff * dna_cum_total

        # ---- m ----
        alpha = (kdm_k + km_k).clamp_min(eps)
        m_inf = S / alpha
        exp_a = torch.exp(-alpha * dt_k)

        m_curr = m_inf + (m_prev - m_inf) * exp_a
        m_curr = m_curr.clamp_min(0.0)

        # ---- mm ----
        exp_d  = torch.exp(-kdm_k * dt_k)
        exp_mr = torch.exp(-km_k * dt_k)

        term1 = mm_prev * exp_d
        term2 = m_inf * (km_k / (kdm_k + eps)) * (1.0 - exp_d)
        term3 = (m_prev - m_inf) * exp_d * (1.0 - exp_mr)

        mm_curr = term1 + term2 + term3
        mm_curr = mm_curr.clamp_min(0.0)

        # ---- total mRNA M = m + mm ----
        M_prev = m_prev + mm_prev
        M_inf  = S / (kdm_k + eps)
        exp_M  = exp_d

        # ---- p ----
        eta  = torch.exp(-kmt_k * dt_k)
        diff = kdm_k - kmt_k
        same = diff.abs() < 1e-6

        int_M_eq = (
            M_inf * (1.0 - eta) / (kmt_k + eps)
            + (M_prev - M_inf) * dt_k * eta
        )

        int_M_gen = (
            M_inf * (1.0 - eta) / (kmt_k + eps)
            + (M_prev - M_inf) * (eta - exp_M) / (diff + eps)
        )

        int_M_conv = torch.where(same, int_M_eq, int_M_gen)

        p_curr = p_prev * eta + VTL_eff * int_M_conv
        p_curr = p_curr.clamp_min(0.0)

        # ---- p*: dpm/dt = O_eff * kmt * p ----
        # Using: kmt ∫p dt = VTL_eff ∫M dt - (p_curr - p_prev)
        int_M_total = (
            M_inf * dt_k
            + (M_prev - M_inf) / (kdm_k + eps) * (1.0 - exp_M)
        )

        pm_increment = O_eff * (
            VTL_eff * int_M_total - (p_curr - p_prev)
        )

        pm_curr = pm_prev + pm_increment
        pm_curr = pm_curr.clamp_min(0.0)

        # ---- store ----
        m_out[:, k]  = m_curr
        mm_out[:, k] = mm_curr
        p_out[:, k]  = p_curr
        pm_out[:, k] = pm_curr
        R_out[:, k]  = R_curr
        O_out[:, k]  = O_curr

        # ---- roll ----
        m_prev  = m_curr
        mm_prev = mm_curr
        p_prev  = p_curr
        pm_prev = pm_curr
        R_prev  = R_curr
        O_prev  = O_curr

    out = torch.cat((m_out, mm_out, p_out, pm_out), dim=2)

    params = torch.cat(
        (VTX_max, kdm, VTL_max, kmt, kmatm, R_out, O_out, lam, lam_O),
        dim=2
    )

    return out, params


# --------------- Closed-loop stacked-GRU with scripted step ------------------
class GRU_model_latent_decay_simple_fb_mat_twostep(nn.Module):
    """
    Closed-loop, stacked GRUCells with state feedback:
      input at step k: [u_k, dna_k, dt_k, log1p(mm_{k-1}), log1p(p*_{k-1})]
      -> stacked GRUCells
      -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.2 ):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers

        in_dim = in_u+2
        # stacked GRUCells
        cells = [nn.GRUCell(in_dim, hidden)]
        cells += [nn.GRUCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)
        
        self.bottle = nn.Sequential(nn.Linear(hidden,  120), nn.SiLU(),
                                    nn.Linear(120,  120), nn.SiLU(),   
                                    )
        self.head = nn.Linear(120, 7)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]
                

        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq = torch.empty_like(mm_out)
        kdm_seq = torch.empty_like(mm_out)
        VTL_seq = torch.empty_like(mm_out)
        kmt1_seq = torch.empty_like(mm_out)
        kmt2_seq = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq   = torch.empty_like(mm_out)
        lam_seq = torch.empty_like(mm_out)


        mm_prev = x0[:, 0:1]  + 0.01                # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01 # start immature m at 0
        pi_prev = torch.zeros_like(mm_prev) + 0.01 # start immature m at 0
        pm_prev = x0[:, 2:3]  + 0.01 
        p_prev  = torch.zeros_like(mm_prev)  + 0.01 
        R_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # hidden states
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]
        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)
        
        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]      # (B,1)
            u_k   = u_seq[:, k]           # (B,U)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            
            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev   # mature mRNA
                pm_gt_prev = pm_prev  # mature protein
  

            if k%100 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k-1, :] 
                pm_gt_prev = y_pm[:, k-1, :] 
                
            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()
            feat_k = torch.cat([torch.sqrt(u_k).clamp_min(0),
                                torch.sqrt(det_mm).clamp_min(0),
                                torch.sqrt(det_pm).clamp_min(0),
                                # torch.sqrt(m_prev),
                                # torch.sqrt(p_prev),
                                ]
                               , dim=-1)  # (B, in_dim) 
            
            x = feat_k
            for li, cell in enumerate(self.cells):
                hs[li] = cell(x, hs[li])
                x = self.dropout(hs[li]) if self.training else hs[li]
            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt1_raw, kmt2_raw, kmatm_raw = raw.split(1, dim=-1)

                 
            lam_k = gamma(lam_raw, 1e-6, 0.0005)
            VTXmax = gamma(VTX_mag, 3e-5, 0.12)
            VTLmax = gamma(VTL_mag, 3e-5, 0.08)
            kdm_k = gamma(kdm_raw, 1e-5, 1e-2)
            kmt1_k = gamma(kmt1_raw, 1e-5, 0.00035)
            kmt2_k = gamma(kmt2_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)
       
            
            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr = ivtt_step_mRNA_two_stage_protein(
                m_prev, mm_prev, p_prev, pi_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt1_k, kmt2_k, kmatm_k
            )
            
            # store
            mm_out[:, k:k+1, :]    = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]   = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]   = pm_curr.unsqueeze(1)

            VTX_seq[:,  k:k+1, :]  = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :]  = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :]  = VTLmax.unsqueeze(1)
            kmt1_seq[:,  k:k+1, :] = kmt1_k.unsqueeze(1)
            kmt2_seq[:,  k:k+1, :] = kmt2_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :]  = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :]  = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :]  = lam_k.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pi_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt1_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())
    

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple

class MZ_model_latent_decay_simple_fb_mat_twostep(nn.Module):
    """
    Mori–Zwanzig (memory + small drift) mapping u(t) -> θ(t), same I/O as your GRU class.

    Inputs per step:
      feat_k = [sqrt(u_k), sqrt(mm_{k-1}), sqrt(p*_{k-1})]   # identical to your GRU features

    Updates:
      # Memory (z) with exponential kernels (Δt-aware):
      z_{k+1} = exp(-Lambda * Δt_k) ⊙ z_k + C * logits_k + alpha_jump * J * sqrt(u_k)

      # Logits (resolved) with tiny drift + memory feedback:
      logits_{k+1} = logits_k + drift([logits_k, h_k, Δt_k]) + W * z_{k+1}

      # θ_k from logits via bottle -> head -> gamma (bounds unchanged)
      # Then call ivtt_step_mRNA_two_stage_protein(...)

    Returns:
      out    : (B,K,3)  [mm, p, p*]
      params : (B,K,7)  [VTX_max, kdm, VTL_max, kmt1, kmatm, R, lam]  # mirrors your template (kmt2 not returned)
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,   # dimension of logits
                 d_h: int = 32,       # feature lift width
                 m_s: int = 16,       # memory atoms
                 dropout: float = 0.0):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h
        self.m_s = m_s

        # ---- Numerics guardrails ----
        self.RATE_MAX = 50.0     # clamp for exp(-rate * dt)
        self.DT_MIN   = 1e-6
        self.DT_MAX   = 1e3
        self.EPS_SQRT = 1e-12

        # in_dim = in_u + 2 (sqrt(mm_prev), sqrt(pm_prev))  -- identical features to your GRU
        in_dim = in_u + 2

        # Feature lift h_k
        self.lift = nn.Sequential(
            nn.Linear(in_dim, d_h),
            nn.SiLU(),
        )

        # ---- MZ memory subsystem ----
        # Positive memory rates via softplus; init roughly log-spaced (slowish)
        self.lambda_mz_raw = nn.Parameter(torch.linspace(-6.0, -3.0, m_s))

        # Couplings
        self.C = nn.Linear(hidden, m_s, bias=False)   # logits -> z
        self.J = nn.Linear(in_u,  m_s, bias=False)    # events (from u) -> z
        self.W = nn.Linear(m_s,  hidden, bias=False)  # z -> logits

        # Small learnable scales to tame early dynamics
        self.alpha_jump  = nn.Parameter(torch.tensor(0.05))  # scales J*sqrt(u)
        self.alpha_coup  = nn.Parameter(torch.tensor(1.0))   # scales W*z contribution

        # Tiny drift on logits: [logits, h_k, dt] -> Δlogits
        self.drift = nn.Sequential(
            nn.Linear(hidden + d_h + 1, 64),
            nn.SiLU(),
            nn.Linear(64, hidden)
        )

        # Init map to seed logits from first-step features
        self.init_map = nn.Linear(d_h, hidden, bias=False)

        # Bottle + head to raw θ logits (7 channels like your GRU head)
        self.bottle = nn.Sequential(
            nn.Linear(hidden, 120), nn.SiLU(),
            nn.Linear(120, 40),     nn.SiLU(),
        )
        self.head = nn.Linear(40, 7)  # [lam, VTX_mag, kdm, VTL_mag, kmt1, kmt2, kmatm]

        # ---- Inits ----
        nn.init.xavier_uniform_(self.C.weight, gain=0.5)
        nn.init.xavier_uniform_(self.J.weight, gain=0.3)
        nn.init.xavier_uniform_(self.W.weight, gain=0.5)
        nn.init.xavier_uniform_(self.init_map.weight, gain=0.3)
        nn.init.xavier_uniform_(self.head.weight); nn.init.zeros_(self.head.bias)

    # Safe exp(-rate * dt): fp32 + clamped exponent, cast back
    def _safe_decay(self, rate: torch.Tensor, dt_k: torch.Tensor) -> torch.Tensor:
        rate = torch.clamp(rate, max=self.RATE_MAX)
        exp_arg = (-rate * dt_k).to(torch.float32).clamp(min=-self.RATE_MAX)
        return torch.exp(exp_arg).to(rate.dtype)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev, dtype = u_seq.device, u_seq.dtype

        # outputs
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # θ streams
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt1_seq  = torch.empty_like(mm_out)
        kmt2_seq  = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = torch.nan_to_num(x0[:, 0:1], nan=0.0).to(dtype) + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pi_prev = torch.zeros_like(mm_prev) + 0.01
        pm_prev = torch.nan_to_num(x0[:, 1:2], nan=0.0).to(dtype) + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # DNA cumulative (matches integrator)
        dna_cum_total = torch.cumsum(torch.nan_to_num(dna_raw, nan=0.0), dim=1)[:, -1, :]  # (B,1)

        # teacher forcing slices
        y_mm = y_seq[:, :, 0:1]
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]

        # MZ memory & rates
        z = torch.zeros(B, self.m_s, device=dev, dtype=dtype)
        lam_mz = F.softplus(self.lambda_mz_raw).clamp(max=self.RATE_MAX)  # (m_s,)

        # initialize logits from first-step features (same feature construction)
        u0 = torch.nan_to_num(u_seq[:, 0], nan=0.0).clamp_min(0.0)
        feat0 = torch.cat([
            torch.sqrt(u0),
            torch.sqrt(mm_prev + self.EPS_SQRT),
            torch.sqrt(pm_prev + self.EPS_SQRT),
        ], dim=-1)
        h0 = self.lift(feat0)
        logits = self.init_map(h0)

        for k in range(K):
            # sanitize dt & inputs
            dt_k = torch.nan_to_num(dt_seq[:, k:k+1], nan=0.0, posinf=self.DT_MAX, neginf=0.0)
            dt_k = dt_k.clamp(min=self.DT_MIN, max=self.DT_MAX)   # (B,1)
            u_k  = torch.nan_to_num(u_seq[:, k],     nan=0.0, posinf=0.0, neginf=0.0).clamp_min(0.0)

            # teacher forcing cadence
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if k == 0:
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev
            if (k % 100 == 0) and teacher_forcing:
                mm_gt_prev = torch.nan_to_num(y_mm[:, k-1, :], nan=0.0)
                pm_gt_prev = torch.nan_to_num(y_pm[:, k-1, :], nan=0.0)

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # ---- features (identical to GRU) ----
            feat_k = torch.cat([
                torch.sqrt(u_k),
                torch.sqrt(det_mm + self.EPS_SQRT),
                torch.sqrt(det_pm + self.EPS_SQRT),
            ], dim=-1)                           # (B, U+2)
            h_k = self.lift(feat_k)              # (B, d_h)

            # ---- memory update: z_{k+1} ----
            decay_mz = self._safe_decay(lam_mz.unsqueeze(0), dt_k)     # (B, m_s)
            e_k = torch.sqrt(u_k + self.EPS_SQRT)                       # event from u
            z = decay_mz * z + self.C(logits) + self.alpha_jump * self.J(e_k)

            # ---- logits update ----
            drift_in = torch.cat([logits, h_k, dt_k], dim=-1)           # (B, hidden + d_h + 1)
            d_logits = self.drift(drift_in)
            logits = logits + d_logits + self.alpha_coup * self.W(z)
            logits = torch.nan_to_num(logits, nan=0.0, posinf=1e6, neginf=-1e6)

            # ---- head -> θ logits -> bounded θ via gamma ----
            z_head = self.bottle(logits)
            raw = self.head(z_head)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt1_raw, kmt2_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw,   1e-6, 5e-4)
            VTXmax  = gamma(VTX_mag,   3e-5, 0.12)
            VTLmax  = gamma(VTL_mag,   3e-5, 0.08)
            kdm_k   = gamma(kdm_raw,   1e-5, 1e-2)
            kmt1_k  = gamma(kmt1_raw,  1e-5, 3.5e-4)
            kmt2_k  = gamma(kmt2_raw,  1e-5, 3.5e-4)
            kmatm_k = gamma(kmatm_raw, 5e-5, 3.5e-3)

            print(m_prev, mm_prev, p_prev, pi_prev, pm_prev, R_prev,
                            dt_k, dna_cum_total,
                            lam_k, VTXmax, kdm_k, VTLmax, kmt1_k, kmt2_k, kmatm_k)
            # ---- analytic two-stage ODE step (unchanged) ----
            m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr = ivtt_step_mRNA_two_stage_protein(
                m_prev, mm_prev, p_prev, pi_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt1_k, kmt2_k, kmatm_k
            )

            # store outputs
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            # store θ streams (keep kmt2 for diagnostics but not in final params concat)
            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt1_seq[:, k:k+1, :] = kmt1_k.unsqueeze(1)
            kmt2_seq[:, k:k+1, :] = kmt2_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll biological states
            m_prev, mm_prev, p_prev, pi_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pi_curr, pm_curr, R_curr

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)

        # Keep 7 channels in params to match your template (omit kmt2 in final concat)
        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt1_seq, kmatm_seq, R_seq, lam_seq],
            dim=-1
        )  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())
    
# --------------- Closed-loop stacked-GRU with scripted step ------------------
class LSTM_model_latent_decay_simple_fb_mat(nn.Module):
    """
    Closed-loop, stacked GRUCells with state feedback:
      input at step k: [u_k, dna_k, dt_k, log1p(mm_{k-1}), log1p(p*_{k-1})]
      -> stacked GRUCells
      -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.2 ):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers

        in_dim = in_u+2
        # stacked GRUCells
        
        cells = [nn.LSTMCell(in_dim, hidden)]
        cells += [nn.LSTMCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)
        
        self.bottle = nn.Sequential(
            nn.Linear(hidden, 64), nn.SiLU(),
            nn.Linear(64,  32),    nn.SiLU()
        )
        self.head = nn.Linear(32, 6)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]
        
        # init
        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)
            # (Good practice) set forget-gate bias to 1.0 for better long-range memory
            H = c.bias_hh.shape[0] // 4
            with torch.no_grad():
                c.bias_hh[H:2*H].fill_(1.0)
                c.bias_ih[H:2*H].fill_(1.0)
                
    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype
        
                # hidden & cell states for each LSTM layer
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]
        cs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq = torch.empty_like(mm_out)
        kdm_seq = torch.empty_like(mm_out)
        VTL_seq = torch.empty_like(mm_out)
        kmt_seq = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq   = torch.empty_like(mm_out)
        lam_seq = torch.empty_like(mm_out)

        # param_features

        # ODE states (choose convention: observed mRNA is matured)

        mm_prev = x0[:, 0:1]  + 0.01                # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01 # start immature m at 0
        pm_prev = x0[:, 2:3]  + 0.01 
        p_prev  = torch.zeros_like(mm_prev)  + 0.01 
        R_prev  = torch.ones_like(mm_prev)

        lam_k_feat = torch.ones_like(mm_prev)
        VTXmax_feat = torch.ones_like(mm_prev)
        VTLmax_feat = torch.ones_like(mm_prev)
        kdm_k_feat = torch.ones_like(mm_prev)
        kmt_k_feat = torch.ones_like(mm_prev)
        kmatm_k_feat = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # hidden states
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]
        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)
        
        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]      # (B,1)
            u_k   = u_seq[:, k]           # (B,U)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            
            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev   # mature mRNA
                pm_gt_prev = pm_prev  # mature protein

            if k%12 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k-1, :] 
                pm_gt_prev = y_pm[:, k-1, :] 
                
                
            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()
            feat_k = torch.cat([u_k,
                                torch.log1p(det_mm.clamp_min(0)),
                                torch.log1p(det_pm.clamp_min(0)),
                                # lam_k_feat,
                                # VTXmax_feat,
                                # VTLmax_feat,
                                # kdm_k_feat,
                                # kmt_k_feat,
                            ]
                               , dim=-1)  # (B, in_dim) 
            

            x = feat_k  # (B, in_dim)
            for li, cell in enumerate(self.cells):
                h_i, c_i = cell(x, (hs[li], cs[li]))     # pass (h, c)
                hs[li], cs[li] = h_i, c_i                # update states
                x = self.dropout(h_i) if self.training else h_i
            h=x   
                
            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

                  
            lam_k = gamma(lam_raw, 1e-6, 0.0005)
            VTXmax = gamma(VTX_mag, 5e-5, 0.15)
            VTLmax = gamma(VTL_mag, 5e-5, 0.1)
            kdm_k = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 1e-5, 0.0035)
            
            lam_k_feat   = ( lam_k.detach() / 0.0005 ) * 1000   
            VTXmax_feat  = ( VTXmax.detach()  / 0.1 ) * 1000  
            VTLmax_feat  = ( VTLmax.detach()  / 0.08 ) * 1000   
            kdm_k_feat   = ( kdm_k.detach()  / 1e-2 ) * 1000   
            kmt_k_feat   = ( kmt_k.detach()  / 0.00035 ) * 1000   
            kmatm_k_feat = ( kmatm_k.detach()  / 0.0035 ) * 1000       
            
            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            @torch.jit.script
            def integrate_vectors_analytical_R_mRNA_maturation(
                    x0: torch.Tensor,      # (B,5)  [m0, mm0, p0, p*0, R0]
                    dna: torch.Tensor,     # (B,K,1)
                    dt: torch.Tensor,      # (B,K)
                    VTX_max: torch.Tensor, # (B,K,1)
                    kdm: torch.Tensor,     # (B,K,1)
                    VTL_max: torch.Tensor, # (B,K,1)
                    kmt: torch.Tensor,     # (B,K,1)   protein maturation rate
                    kmatm: torch.Tensor,   # (B,K,1)   mRNA maturation rate (m -> mm)
                    lam: torch.Tensor      # (B,K,1)   resource decay λ (expand beforehand if per-seq)
            ) -> Tuple[torch.Tensor, torch.Tensor]:
                """
                Analytic IVTT with single resource decay and mRNA maturation:

                    dR/dt   = -λ R
                    dm/dt   = S - (kdm + kmatm) m                 ,  S = R VTX_max [DNA]_cum
                    dmm/dt  = kmatm m - kdm mm
                    dp/dt   = (R VTL_max) (m + mm) - kmt p
                    dpm/dt  = kmt p

                Assumes parameters are frozen on each [t_{k-1}, t_k) and uses the end-of-step
                R_k = R_{k-1} exp(-λ Δt) as the effective constant within the step.

                Returns:
                  out    : (B,K,4)  channels [m, mm, p, p*]
                  params : (B,K,7)  [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
                """
                eps: float = 1e-9
                B, K, _ = dna.shape

                # ---------- output buffers ----------
                m_out  = torch.empty((B, K, 1), device=x0.device, dtype=x0.dtype)
                mm_out = torch.empty_like(m_out)
                p_out  = torch.empty_like(m_out)
                pm_out = torch.empty_like(m_out)
                R_out  = torch.empty_like(m_out)

                # total DNA per sequence (constant within each step, like your simple solver)
                dna_cum_total = torch.cumsum(dna, dim=1)[:, -1, :]  # (B,1)

                # ---------- initial state -----------
                m_prev   = x0[:, 0:1]              # (B,1)
                p_prev   = x0[:, 1:2]              # (B,1)
                pm_prev  = x0[:, 2:3]              # (B,1)
                R_prev   = x0[:, 3:4].clamp_min(eps)  # (B,1)
                mm_prev  = x0[:, 4:5]              # (B,1)

                # (Optional safety) allow lam given as (B,1) by expanding once
                if lam.size(1) == 1:
                    lam = lam.expand(B, K, 1)

                for k in range(K):
                    dt_k   = dt[:, k:k+1]          # (B,1)

                    # ---- per-step params (B,1) ----
                    lam_k  = lam[:,     k]         # (B,1)
                    kdm_k  = kdm[:,     k]
                    km_k   = kmatm[:,   k]
                    kmt_k  = kmt[:,     k]
                    VTX_k  = VTX_max[:, k]
                    VTL_k  = VTL_max[:, k]

                    # ---- resource decay  R_k = R_{k-1} e^{-λ Δt} ----
                    rho    = torch.exp(-lam_k * dt_k)
                    R_curr = R_prev * rho

                    # ---- effective rates & source term ----
                    VTX_eff = R_curr * VTX_k
                    VTL_eff = R_curr * VTL_k
                    S       = VTX_eff * dna_cum_total          # (B,1) constant in step

                    # ---- m (immature mRNA): dm/dt = S - (kdm+km) m ----
                    alpha  = (kdm_k + km_k).clamp_min(eps)
                    m_inf  = S / alpha
                    exp_a  = torch.exp(-alpha * dt_k)
                    m_curr = m_inf + (m_prev - m_inf) * exp_a
                    m_curr = m_curr.clamp_min(0.)

                    # ---- mm (mature mRNA): dmm/dt = km m - kdm mm (closed form) ----
                    exp_d  = torch.exp(-kdm_k * dt_k)          # e^{-kdm Δt}
                    exp_mr = torch.exp(-km_k  * dt_k)          # e^{-km   Δt}
                    term1  = mm_prev * exp_d
                    term2  = m_inf * (km_k / (kdm_k + eps)) * (1. - exp_d)
                    term3  = (m_prev - m_inf) * exp_d * (1. - exp_mr)
                    mm_curr = term1 + term2 + term3
                    mm_curr = mm_curr.clamp_min(0.)

                    # ---- total M = m + mm (for protein) obeys dM/dt = S - kdm M ----
                    M_prev = m_prev + mm_prev
                    M_inf  = S / (kdm_k + eps)
                    exp_M  = exp_d                           # e^{-kdm Δt}

                    # ---- protein p: dp/dt = VTL_eff * M - kmt p ----
                    eta    = torch.exp(-kmt_k * dt_k)        # e^{-kmt Δt}
                    diff   = kdm_k - kmt_k
                    same   = diff.abs() < 1e-6

                    int_M_eq  = (M_inf * (1. - eta) / (kmt_k + eps)
                                 + (M_prev - M_inf) * dt_k * eta)
                    int_M_gen = (M_inf * (1. - eta) / (kmt_k + eps)
                                 + (M_prev - M_inf) * (eta - exp_M) / (diff + eps))
                    int_M_conv = torch.where(same, int_M_eq, int_M_gen)

                    p_curr = p_prev * eta + VTL_eff * int_M_conv
                    p_curr = p_curr.clamp_min(0.)

                    # ---- mature protein p*: conservation d/dt(p+p*) = VTL_eff * M ----
                    int_M_total = (M_inf * dt_k
                                   + (M_prev - M_inf) / (kdm_k + eps) * (1. - exp_M))
                    pm_curr = pm_prev + (p_prev - p_curr) + VTL_eff * int_M_total
                    pm_curr = pm_curr.clamp_min(0.)

                    # ---- store (same style as your simple solver) ----
                    m_out[:,  k]  = m_curr
                    mm_out[:, k]  = mm_curr
                    p_out[:,  k]  = p_curr
                    pm_out[:, k]  = pm_curr
                    R_out[:,  k]  = R_curr

                    # ---- roll ----
                    m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

                out = torch.cat((mm_out, p_out, pm_out), dim=2)                      # (B,K,4)
                params = torch.cat((VTX_max, kdm, VTL_max, kmt, kmatm, R_out, lam), dim=2)  # (B,K,7)
                return out, params
                                   
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())


# --------------- Closed-loop stacked-LSTM with scripted step ------------------
class LSTM_model_latent_decay_simple_fb_matO(nn.Module):
    """
    Closed-loop, stacked LSTMCells with state feedback:
      input at step k: [u_k, dna_k, dt_k, log1p(mm_{k-1}), log1p(p*_{k-1})]
      -> stacked LSTMCells
      -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,8) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam, lamO]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.2):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers

        in_dim = in_u + 2

        # stacked LSTMCells
        cells = [nn.LSTMCell(in_dim, hidden)]
        cells += [nn.LSTMCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)

        self.bottle = nn.Sequential(
            nn.Linear(hidden, 128),
            nn.SiLU(),
            nn.Linear(128, 64),
            nn.SiLU(),
        )

        self.head = nn.Linear(64, 7)

        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)

        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)
        lamO_seq  = torch.empty_like(mm_out)

        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 2:3] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # LSTM hidden and cell states
        hs = [
            torch.zeros(B, self.hidden, device=dev, dtype=dtype)
            for _ in range(self.num_layers)
        ]
        cs = [
            torch.zeros(B, self.hidden, device=dev, dtype=dtype)
            for _ in range(self.num_layers)
        ]

        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]   # (B,1)
            u_k  = u_seq[:, k]        # (B,U)

            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev

            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev

            if k % 200 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            feat_k = torch.cat(
                [
                    torch.sqrt(u_k).clamp_min(0),
                    torch.sqrt(det_mm).clamp_min(1),
                    torch.sqrt(det_pm).clamp_min(1),
                    # torch.sqrt(R_prev),
                    # torch.sqrt(O_prev),
                ],
                dim=-1,
            )  # (B, in_dim)

            x = feat_k
            for li, cell in enumerate(self.cells):
                hs[li], cs[li] = cell(x, (hs[li], cs[li]))
                x = self.dropout(hs[li]) if self.training else hs[li]

            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)

            lam_raw, lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw, 1e-6, 0.0005)
            lam_O   = gamma(lamO_raw, 1e-6, 0.0005)
            VTXmax  = gamma(VTX_mag, 5e-5, 0.1)
            VTLmax  = gamma(VTL_mag, 5e-5, 0.06)
            kdm_k   = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)

            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev,
                dt_k, dna_cum_total,
                lam_k, lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :] = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1, :] = p_curr.unsqueeze(1)
            pm_out[:, k:k+1, :] = pm_curr.unsqueeze(1)

            VTX_seq[:,   k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,   k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,   k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,   k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:, k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,     k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,   k:k+1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k+1, :] = lam_O.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev = (
                m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
            )

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]

        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq],
            dim=-1,
        )  # (B,K,8)

        return (out, params) if self.training else (out, params.detach())
    
# --------------- Closed-loop stacked-GRU with scripted step ------------------
class GRU_model_latent_decay_simple_fb_matO(nn.Module):
    """
    Closed-loop, stacked GRUCells with state feedback:
      input at step k: [u_k, dna_k, dt_k, log1p(mm_{k-1}), log1p(p*_{k-1})]
      -> stacked GRUCells
      -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.2 ):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers

        in_dim = in_u+2
        # stacked GRUCells
        cells = [nn.GRUCell(in_dim, hidden)]
        cells += [nn.GRUCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)
        
        self.bottle = nn.Sequential(nn.Linear(hidden,  128), nn.SiLU(),
                                    nn.Linear(128,  64), nn.SiLU(),   
                                    )
        self.head = nn.Linear(64, 7)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]
                

        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq = torch.empty_like(mm_out)
        kdm_seq = torch.empty_like(mm_out)
        VTL_seq = torch.empty_like(mm_out)
        kmt_seq = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq   = torch.empty_like(mm_out)
        lam_seq = torch.empty_like(mm_out)
        lamO_seq = torch.empty_like(mm_out)


        mm_prev = x0[:, 0:1]  + 0.01                # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01 # start immature m at 0
        pm_prev = x0[:, 2:3]  + 0.01 
        p_prev  = torch.zeros_like(mm_prev)  + 0.01 
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)
        
        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # hidden states
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]
        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)
        
        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]      # (B,1)
            u_k   = u_seq[:, k]           # (B,U)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            
            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev   # mature mRNA
                pm_gt_prev = pm_prev  # mature protein
  

            if k%200 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k-1, :] 
                pm_gt_prev = y_pm[:, k-1, :] 
                
            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()
            feat_k = torch.cat([torch.sqrt(u_k).clamp_min(0),
                                torch.sqrt(det_mm).clamp_min(1),
                                torch.sqrt(det_pm).clamp_min(1),
                                # torch.sqrt(R_prev),
                                # torch.sqrt(O_prev),
                                ]
                               , dim=-1)  # (B, in_dim) 
            
            x = feat_k
            for li, cell in enumerate(self.cells):
                hs[li] = cell(x, hs[li])
                x = self.dropout(hs[li]) if self.training else hs[li]
            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)
            lam_raw,lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

                 
            lam_k = gamma(lam_raw, 1e-6, 0.0005)
            lam_O = gamma(lamO_raw, 1e-6, 0.0005)
            VTXmax = gamma(VTX_mag, 5e-5, 0.1)
            VTLmax = gamma(VTL_mag, 5e-5, 0.06)
            kdm_k = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)
       
            
            # ---- one scripted step ----

            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,O_prev,
                dt_k, dna_cum_total,
                lam_k,lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k)
            
            # store
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k+1, :] = lam_O.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev , O_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())

# --------------- Closed-loop stacked-LSTM with scripted step ------------------
class LSTM_model_latent_decay_simple_fb_matO1(nn.Module):
    """
    Closed-loop, stacked LSTMCells with state feedback:
      input at step k: [sqrt(u_k), sqrt(mm_{k-1}), sqrt(p*_{k-1})]
      -> stacked LSTMCells
      -> θ_k = [λ, λO, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_R_O_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,8) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam, lamO]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.1):
        super().__init__()
        assert num_layers >= 1

        self.hidden = hidden
        self.num_layers = num_layers

        in_dim = in_u + 2

        # stacked LSTMCells
        cells = [nn.LSTMCell(in_dim, hidden)]
        cells += [nn.LSTMCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)

        self.dropout = nn.Dropout(dropout)

        self.bottle = nn.Sequential(
            nn.Linear(hidden, 128),
            nn.SiLU(),
            nn.Linear(128, 64),
            nn.SiLU(),
        )

        self.head = nn.Linear(64, 7)

        # LSTM-specific initialization
        for c in self.cells:
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.orthogonal_(c.weight_hh)

            nn.init.zeros_(c.bias_ih)
            nn.init.zeros_(c.bias_hh)

            # PyTorch LSTM gate order:
            # [input gate, forget gate, cell/update gate, output gate]
            H = c.hidden_size

            # Positive forget-gate bias helps LSTM retain memory at initialization.
            with torch.no_grad():
                c.bias_ih[H:2 * H].fill_(1.0)
                c.bias_hh[H:2 * H].fill_(1.0)

        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,3): [m_obs0, p0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs: mm, p, pm
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)
        lamO_seq  = torch.empty_like(mm_out)

        mm_prev = x0[:, 0:1] + 0.01                 # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01  # immature mRNA
        pm_prev = x0[:, 2:3] + 0.01                 # mature protein
        p_prev  = torch.zeros_like(mm_prev) + 0.01  # immature protein
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # LSTM hidden and cell states
        hs = [
            torch.zeros(B, self.hidden, device=dev, dtype=dtype)
            for _ in range(self.num_layers)
        ]
        cs = [
            torch.zeros(B, self.hidden, device=dev, dtype=dtype)
            for _ in range(self.num_layers)
        ]

        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)

        for k in range(K):
            dt_k = dt_seq[:, k:k + 1]  # (B,1)
            u_k  = u_seq[:, k]         # (B,U)

            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev

            if k == 0:
                # for step 0, use provided initial observation x0
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev

            if k % 75 == 0 and teacher_forcing == True:
                
                if k > 1:
                    # use ground-truth from previous step if available
                    mm_gt_prev = y_mm[:, k - 1, :]
                    pm_gt_prev = y_pm[:, k - 1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # safer feedback scaling for LSTM gates
            feat_k = torch.cat(
                [
                    torch.sqrt(u_k.clamp_min(0.0) + 1e-6),
                    torch.sqrt(det_mm.clamp_min(0.0) + 1e-6),
                    torch.sqrt(det_pm.clamp_min(0.0) + 1e-6),
                    # torch.sqrt(R_prev.clamp_min(0.0) + 1e-6),
                    # torch.sqrt(O_prev.clamp_min(0.0) + 1e-6),
                ],
                dim=-1,
            )  # (B, in_dim)

            x = feat_k

            for li, cell in enumerate(self.cells):
                hs[li], cs[li] = cell(x, (hs[li], cs[li]))

                # Apply dropout only between recurrent layers, not after final layer.
                if self.training and li < self.num_layers - 1:
                    x = self.dropout(hs[li])
                else:
                    x = hs[li]

            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)

            lam_raw, lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw, 1e-6, 0.0005)
            lam_O   = gamma(lamO_raw, 1e-6, 0.0005)
            VTXmax  = gamma(VTX_mag, 5e-5, 0.1)
            VTLmax  = gamma(VTL_mag, 5e-5, 0.06)
            kdm_k   = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)

            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev,
                dt_k, dna_cum_total,
                lam_k, lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store outputs
            mm_out[:, k:k + 1, :] = mm_curr.unsqueeze(1)
            p_out[:,  k:k + 1, :] = p_curr.unsqueeze(1)
            pm_out[:, k:k + 1, :] = pm_curr.unsqueeze(1)

            # store diagnostics
            VTX_seq[:,   k:k + 1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,   k:k + 1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,   k:k + 1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,   k:k + 1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:, k:k + 1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,     k:k + 1, :] = R_curr.unsqueeze(1)
            lam_seq[:,   k:k + 1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k + 1, :] = lam_O.unsqueeze(1)

            # roll states
            m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev = (
                m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
            )

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]

        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq],
            dim=-1,
        )  # (B,K,8)

        return (out, params) if self.training else (out, params.detach())

class StableLSTMCellLayer(nn.Module):
    """
    TorchScript-safe LSTMCell + LayerNorm wrapper.

    This avoids doing:
        self.hidden_norms[li](h)

    because TorchScript does not allow ModuleList indexing with a runtime index.
    """
    def __init__(self, input_dim: int, hidden: int):
        super().__init__()
        self.cell = nn.LSTMCell(input_dim, hidden)
        self.norm = nn.LayerNorm(hidden)

    def forward(self,
                x: torch.Tensor,
                h: torch.Tensor,
                c: torch.Tensor,
                cell_clip: float,
                hidden_clip: float) -> Tuple[torch.Tensor, torch.Tensor]:

        h_new, c_new = self.cell(x, (h, c))

        if cell_clip > 0.0:
            c_new = torch.clamp(c_new, -cell_clip, cell_clip)

        if hidden_clip > 0.0:
            h_new = torch.clamp(h_new, -hidden_clip, hidden_clip)

        h_new = self.norm(h_new)

        return h_new, c_new


# --------------- Stable closed-loop stacked-LSTM with scripted step ------------------
class LSTM_model_latent_decay_simple_fb_matO_stable(nn.Module):
    """
    Stable closed-loop, stacked LSTMCells with state feedback:
      input at step k: [u_k, sqrt(mm_{k-1}), sqrt(p*_{k-1})]
      -> normalized stacked LSTMCells
      -> θ_k = [λ, λO, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> optional theta smoothing
      -> ivtt_step_R_O_mRNA_maturation() -> states for next step

    Stability tricks:
      - TorchScript-safe StableLSTMCellLayer wrappers
      - positive forget-gate bias
      - per-gate orthogonal recurrent init
      - LayerNorm on input and hidden states
      - LSTM cell-state clipping
      - hidden-state clipping
      - optional truncated BPTT via detach_every
      - small final-head initialization
      - safer sqrt feedback features
      - optional parameter smoothing across time
      - teacher-forcing bugfix: no y_seq[:, -1] leakage at k=0

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,8) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam, lamO]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.1,
                 forget_bias: float = 2.0,
                 cell_clip: float = 10.0,
                 hidden_clip: float = 10.0,
                 detach_every: int = 512,
                 param_smoothing: float = 0.90,
                 state_clip: float = 1e9,
                 eps: float = 1e-8):
        super().__init__()

        assert num_layers >= 1

        self.hidden = int(hidden)
        self.num_layers = int(num_layers)

        self.cell_clip = float(cell_clip)
        self.hidden_clip = float(hidden_clip)
        self.detach_every = int(detach_every)
        self.param_smoothing = float(param_smoothing)
        self.state_clip = float(state_clip)
        self.eps = float(eps)

        in_dim = in_u + 2

        self.input_norm = nn.LayerNorm(in_dim)

        layers = [StableLSTMCellLayer(in_dim, hidden)]
        layers += [
            StableLSTMCellLayer(hidden, hidden)
            for _ in range(num_layers - 1)
        ]
        self.layers = nn.ModuleList(layers)

        self.dropout = nn.Dropout(dropout)

        self.bottle = nn.Sequential(
            nn.Linear(hidden, 128),
            nn.SiLU(),
            nn.LayerNorm(128),
            nn.Linear(128, 64),
            nn.SiLU(),
            nn.LayerNorm(64),
        )

        self.head = nn.Linear(64, 7)

        self._init_lstm_cells(forget_bias=float(forget_bias))

        # Small head init prevents initial parameter saturation / ODE explosions.
        nn.init.normal_(self.head.weight, std=0.01)
        nn.init.zeros_(self.head.bias)

    def _init_lstm_cells(self, forget_bias: float):
        H = self.hidden

        for layer in self.layers:
            c = layer.cell

            # PyTorch LSTMCell gate order:
            # [input gate, forget gate, cell/update gate, output gate]
            for gate in range(4):
                nn.init.xavier_uniform_(c.weight_ih[gate * H:(gate + 1) * H])
                nn.init.orthogonal_(c.weight_hh[gate * H:(gate + 1) * H])

            nn.init.zeros_(c.bias_ih)
            nn.init.zeros_(c.bias_hh)

            # Positive forget bias makes the LSTM initially retain memory better.
            # Effective bias is bias_ih + bias_hh. Here only bias_ih is set.
            with torch.no_grad():
                c.bias_ih[H:2 * H].fill_(forget_bias)

    def _clean_state(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.nan_to_num(
            x,
            nan=0.0,
            posinf=self.state_clip,
            neginf=0.0,
        )
        x = torch.clamp_min(x, 0.0)

        if self.state_clip > 0.0:
            x = torch.clamp_max(x, self.state_clip)

        return x

    def forward(self,
                x0:      torch.Tensor,   # (B,3): [m_obs0, p0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True,
                tf_every: int = 200) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)
        lamO_seq  = torch.empty_like(mm_out)

        mm_prev = x0[:, 0:1] + 0.01                 # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01  # start immature m at 0
        pm_prev = x0[:, 2:3] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # LSTM hidden and cell states
        hs = torch.jit.annotate(List[torch.Tensor], [])
        cs = torch.jit.annotate(List[torch.Tensor], [])

        for _ in range(self.num_layers):
            hs.append(torch.zeros(B, self.hidden, device=dev, dtype=dtype))
            cs.append(torch.zeros(B, self.hidden, device=dev, dtype=dtype))

        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)

        # Previous bounded parameters for optional low-pass smoothing.
        # Initialized as empty tensors with correct shape.
        lam_prev_param   = torch.empty(B, 1, device=dev, dtype=dtype)
        lamO_prev_param  = torch.empty(B, 1, device=dev, dtype=dtype)
        VTX_prev_param   = torch.empty(B, 1, device=dev, dtype=dtype)
        VTL_prev_param   = torch.empty(B, 1, device=dev, dtype=dtype)
        kdm_prev_param   = torch.empty(B, 1, device=dev, dtype=dtype)
        kmt_prev_param   = torch.empty(B, 1, device=dev, dtype=dtype)
        kmatm_prev_param = torch.empty(B, 1, device=dev, dtype=dtype)

        for k in range(K):

            # Truncated BPTT: keep numerical values, cut graph.
            if self.detach_every > 0 and k > 0 and (k % self.detach_every == 0):
                new_hs_detached = torch.jit.annotate(List[torch.Tensor], [])
                new_cs_detached = torch.jit.annotate(List[torch.Tensor], [])

                for h in hs:
                    new_hs_detached.append(h.detach())

                for c in cs:
                    new_cs_detached.append(c.detach())

                hs = new_hs_detached
                cs = new_cs_detached

                m_prev  = m_prev.detach()
                mm_prev = mm_prev.detach()
                p_prev  = p_prev.detach()
                pm_prev = pm_prev.detach()
                R_prev  = R_prev.detach()
                O_prev  = O_prev.detach()

            dt_k = dt_seq[:, k:k+1]      # (B,1)
            u_k  = u_seq[:, k]           # (B,U)

            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev

            # Teacher forcing bugfix:
            # require k > 0, otherwise k - 1 == -1 and leaks the final sequence value.
            if (
                75
                and k > 0
                and tf_every > 0
                and (k % tf_every == 0)
            ):
                mm_gt_prev = y_mm[:, k - 1, :]
                pm_gt_prev = y_pm[:, k - 1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # Safer feedback features:
            # clamp before sqrt to avoid NaNs from tiny negative numerical values.
            feat_k = torch.cat(
                [
                    torch.sqrt(u_k.clamp_min(0.0) + self.eps),
                    torch.sqrt(det_mm.clamp_min(0.0) + self.eps).clamp_min(1.0),
                    torch.sqrt(det_pm.clamp_min(0.0) + self.eps).clamp_min(1.0),
                    # torch.sqrt(R_prev.clamp_min(0.0) + self.eps),
                    # torch.sqrt(O_prev.clamp_min(0.0) + self.eps),
                ],
                dim=-1,
            )  # (B, in_dim)

            feat_k = torch.nan_to_num(
                feat_k,
                nan=0.0,
                posinf=1e6,
                neginf=0.0,
            )

            x = self.input_norm(feat_k)

            new_hs = torch.jit.annotate(List[torch.Tensor], [])
            new_cs = torch.jit.annotate(List[torch.Tensor], [])

            for li, layer in enumerate(self.layers):
                h_new, c_new = layer(
                    x,
                    hs[li],
                    cs[li],
                    self.cell_clip,
                    self.hidden_clip,
                )

                new_hs.append(h_new)
                new_cs.append(c_new)

                # Dropout only between layers, not on the final representation.
                if li < self.num_layers - 1:
                    if self.training:
                        x = self.dropout(h_new)
                    else:
                        x = h_new
                else:
                    x = h_new

            hs = new_hs
            cs = new_cs

            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)

            lam_raw, lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw,   1e-6,  0.0005)
            lam_O   = gamma(lamO_raw,  1e-6,  0.0005)
            VTXmax  = gamma(VTX_mag,   5e-5,  0.1)
            VTLmax  = gamma(VTL_mag,   5e-5,  0.06)
            kdm_k   = gamma(kdm_raw,   1e-5,  1e-2)
            kmt_k   = gamma(kmt_raw,   1e-5,  0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5,  0.0035)

            # Optional low-pass smoothing of parameters.
            # This often helps closed-loop mechanistic systems converge.
            if self.param_smoothing > 0.0 and k > 0:
                a = self.param_smoothing

                lam_k   = lam_prev_param.detach()   
                lam_O   = lamO_prev_param.detach()  
                VTXmax  = VTX_prev_param.detach()
                VTLmax  = VTL_prev_param.detach()   
                kdm_k   = kdm_prev_param.detach()   
                kmt_k   = kmt_prev_param.detach()   
                kmatm_k = kmatm_prev_param.detach() 

            lam_prev_param   = lam_k
            lamO_prev_param  = lam_O
            VTX_prev_param   = VTXmax
            VTL_prev_param   = VTLmax
            kdm_prev_param   = kdm_k
            kmt_prev_param   = kmt_k
            kmatm_prev_param = kmatm_k

            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev,
                dt_k, dna_cum_total,
                lam_k, lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # Clean states to prevent one bad numerical step from killing training.
            m_curr  = self._clean_state(m_curr)
            mm_curr = self._clean_state(mm_curr)
            p_curr  = self._clean_state(p_curr)
            pm_curr = self._clean_state(pm_curr)
            R_curr  = self._clean_state(R_curr)
            O_curr  = self._clean_state(O_curr)

            # store
            mm_out[:, k:k+1, :] = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1, :] = p_curr.unsqueeze(1)
            pm_out[:, k:k+1, :] = pm_curr.unsqueeze(1)

            VTX_seq[:,   k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,   k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,   k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,   k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:, k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,     k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,   k:k+1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k+1, :] = lam_O.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev = (
                m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
            )

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]

        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq],
            dim=-1,
        )  # (B,K,8)

        return (out, params) if self.training else (out, params.detach())

# --------------- Closed-loop stacked-GRU with scripted step ------------------
class GRU_model_latent_decay_simple_fb_mat(nn.Module):
    """
    Closed-loop, stacked GRUCells with state feedback:
      input at step k: [u_k, dna_k, dt_k, log1p(mm_{k-1}), log1p(p*_{k-1})]
      -> stacked GRUCells
      -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 num_layers: int = 2,
                 dropout: float = 0.2 ):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers
    def make_train_test_split(self, *, test_frac=0.125, val_frac=0.125):
        N = len(self.x0_list)
        self.choice = random.choice(range(100))
        rng = random.Random(self.choice)
        idx = list(range(N))
        rng.shuffle(idx)
    
        n_test = int(N * test_frac)
        self.test_idx = idx[:n_test]
        rest = idx[n_test:]
    
        n_val = int(len(rest) * val_frac)
        self.val_idx = rest[:n_val] if n_val > 0 else []
        self.train_idx = rest[n_val:]
    
        msg = f"Split → {len(self.train_idx)} train"
        if self.val_idx: msg += f" | {len(self.val_idx)} val"
        msg += f" | {len(self.test_idx)} test"


        in_dim = in_u+2
        # stacked GRUCells
        cells = [nn.GRUCell(in_dim, hidden)]
        cells += [nn.GRUCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)
        
        self.bottle = nn.Sequential(nn.Linear(hidden,  120), nn.SiLU(),
                                    nn.Linear(120,  40), nn.SiLU(),   
                                    )
        self.head = nn.Linear(40, 6)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]
                

        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq = torch.empty_like(mm_out)
        kdm_seq = torch.empty_like(mm_out)
        VTL_seq = torch.empty_like(mm_out)
        kmt_seq = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq   = torch.empty_like(mm_out)
        lam_seq = torch.empty_like(mm_out)


        mm_prev = x0[:, 0:1]  + 0.01                # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01 # start immature m at 0
        pm_prev = x0[:, 2:3]  + 0.01 
        p_prev  = torch.zeros_like(mm_prev)  + 0.01 
        R_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # hidden states
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]
        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)
        
        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]      # (B,1)
            u_k   = u_seq[:, k]           # (B,U)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            
            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev   # mature mRNA
                pm_gt_prev = pm_prev  # mature protein
  

            if k%100 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k-1, :] 
                pm_gt_prev = y_pm[:, k-1, :] 
                
            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()
            feat_k = torch.cat([torch.sqrt(u_k).clamp_min(0),
                                torch.sqrt(det_mm).clamp_min(0),
                                torch.sqrt(det_pm).clamp_min(0),
                                # torch.sqrt(m_prev),
                                # torch.sqrt(p_prev),
                                ]
                               , dim=-1)  # (B, in_dim) 
            
            x = feat_k
            for li, cell in enumerate(self.cells):
                hs[li] = cell(x, hs[li])
                x = self.dropout(hs[li]) if self.training else hs[li]
            h = x  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

                 
            lam_k = gamma(lam_raw, 1e-6, 0.0005)
            VTXmax = gamma(VTX_mag, 3e-5, 0.12)
            VTLmax = gamma(VTL_mag, 3e-5, 0.08)
            kdm_k = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)
       
            
            # ---- one scripted step ----

            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )
            
            # store
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())
    
# --------------- Closed-loop causal-Transformer with scripted step ------------------
class Transformer_model_latent_decay_simple_fb_matO1(nn.Module):
    """
    Closed-loop causal Transformer encoder with state feedback:
      input at step k: [u_k, log1p/sqrt(mm_{k-1}), log1p/sqrt(p*_{k-1})]
      -> lift features
      -> causal Transformer over last `context_len` lifted feature vectors
      -> θ_k = [λ, λO, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_R_O_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,8) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam, lamO]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 lift_dim: int = 32,
                 num_layers: int = 2,
                 dropout: float = 0.0,
                 ff_mult: int = 2,
                 context_len: int = 64):
        super().__init__()

        self.hidden = hidden
        self.num_layers = num_layers
        self.context_len = int(context_len)

        in_dim = in_u + 2

        self.lift = nn.Sequential(
            nn.Linear(in_dim, lift_dim),
            nn.SiLU(),
            nn.Linear(lift_dim, hidden),
        )

        self.pos_embed = nn.Embedding(self.context_len, hidden)

        nhead = max(1, hidden // 32)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden,
            nhead=nhead,
            dim_feedforward=hidden * ff_mult,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )

        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=max(1, num_layers),
            enable_nested_tensor=False,
        )

        self.head = nn.Linear(hidden, 7)

        self.register_buffer(
            "_causal_mask",
            nn.Transformer.generate_square_subsequent_mask(self.context_len),
            persistent=False,
        )

        # Small-weight init, matching the OdeTransformer style
        nn.init.normal_(self.head.weight, std=0.01)
        nn.init.zeros_(self.head.bias)

        # Reduce initial position-embedding variance
        nn.init.normal_(self.pos_embed.weight, std=0.02)

    def forward(self,
                x0:      torch.Tensor,   # (B,3): [m_obs0, p0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)
        lamO_seq  = torch.empty_like(mm_out)

        mm_prev = x0[:, 0:1] + 0.01                 # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01  # start immature m at 0
        pm_prev = x0[:, 2:3] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)

        feat_history: List[torch.Tensor] = []

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]      # (B,1)
            u_k  = u_seq[:, k]           # (B,U)

            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev

            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev

            if k % 200 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k - 1, :]
                pm_gt_prev = y_pm[:, k - 1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            feat_k = torch.cat(
                [
                    torch.sqrt(u_k).clamp_min(0),
                    torch.sqrt(det_mm).clamp_min(1),
                    torch.sqrt(det_pm).clamp_min(1),
                    # torch.sqrt(R_prev),
                    # torch.sqrt(O_prev),
                ],
                dim=-1,
            )  # (B, in_dim)

            feat = self.lift(feat_k)  # (B, hidden)
            feat_history.append(feat)

            # Detach features that have scrolled out of the context window so
            # the backward graph stays bounded at O(K * context_len) tensors.
            if len(feat_history) > self.context_len:
                feat_history[-self.context_len - 1] = (
                    feat_history[-self.context_len - 1].detach()
                )

            start = max(0, len(feat_history) - self.context_len)
            window: List[torch.Tensor] = feat_history[start:]
            W = len(window)

            seq = torch.stack(window, dim=1)  # (B, W, hidden)

            # Window-relative positional embedding: 0 = oldest, W-1 = newest
            pos_ids = torch.arange(W, device=dev, dtype=torch.long)
            seq = seq + self.pos_embed(pos_ids).unsqueeze(0)

            mask = self._causal_mask[:W, :W].to(device=dev, dtype=seq.dtype)
            out = self.transformer(seq, mask=mask, is_causal=True)

            h = out[:, -1, :]  # (B, hidden)

            # head → raw params
            raw = self.head(h)

            lam_raw, lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw, 1e-6, 0.0005)
            lam_O   = gamma(lamO_raw, 1e-6, 0.0005)
            VTXmax  = gamma(VTX_mag, 5e-5, 0.1)
            VTLmax  = gamma(VTL_mag, 5e-5, 0.06)
            kdm_k   = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)

            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev,
                dt_k, dna_cum_total,
                lam_k, lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :] = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1, :] = p_curr.unsqueeze(1)
            pm_out[:, k:k+1, :] = pm_curr.unsqueeze(1)

            VTX_seq[:,   k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,   k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,   k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,   k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:, k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,     k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,   k:k+1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k+1, :] = lam_O.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev = (
                m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
            )

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]

        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq],
            dim=-1,
        )  # (B,K,8)

        return (out, params) if self.training else (out, params.detach())
    
class MZ_model_latent_decay_simple_fb_mat(nn.Module):
    """
    Mori–Zwanzig (memory + small drift) mapping u(t) -> θ(t), same I/O as GRU_model_latent_decay_simple_fb_mat.

    Per-step features (unchanged):
        feat_k = [sqrt(u_k), sqrt(mm_{k-1}), sqrt(p*_{k-1})]

    Updates:
        z_{k+1} = exp(-softplus(lambda_mz) * Δt_k) ⊙ z_k + C * logits_k + J * sqrt(u_k_norm)
        logits_{k+1} = logits_k + tanh(drift([logits_k, h_k, Δt_k]))*0.5 + 0.5 * W * z_{k+1}
        θ_k = γ( head( bottle(logits_k) ) )
        states_{k+1} = ivtt_step_mRNA_maturation(..., θ_k)
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 256,   # logits dimension
                 d_h: int = 64,       # feature lift width
                 m_s: int = 16,       # memory atoms
                 dropout: float = 0.0):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h
        self.m_s = m_s

        # simple, readable safety constants
        self.EPS = 1e-12
        self.EXP_CAP = 50.0      # clamp for exp(-x)
        self.LOGIT_CLIP = 50.0   # logits clamp
        self.Z_CLIP = 1e6        # memory clamp

        # feature lift (same input structure as your GRU features)
        in_dim = in_u + 2
        self.lift = nn.Sequential(
            nn.Linear(in_dim, d_h),
            nn.SiLU(),
        )

        # MZ memory (sum of exponentials) and couplings
        self.lambda_mz_raw = nn.Parameter(torch.linspace(-5, -2.5, m_s))  # softplus() -> ≥0
        self.C = nn.Linear(hidden, m_s, bias=False)   # logits -> z
        self.J = nn.Linear(in_u,  m_s, bias=False)    # events (sqrt(u_norm)) -> z
        self.W = nn.Linear(m_s,  hidden, bias=False)  # z -> logits

        # small drift on logits
        self.drift = nn.Sequential(
            nn.Linear(hidden + d_h + 1, 64),
            nn.SiLU(),
            nn.Linear(64, hidden)
        )

        # init logits from first-step features
        self.init_map = nn.Linear(d_h, hidden, bias=False)

        # bottle + head to θ logits (6 channels for one-stage)
        self.bottle = nn.Sequential(
            nn.Linear(hidden, 120), nn.SiLU(),
            nn.Linear(120, 120),     nn.SiLU(),
        )
        self.head = nn.Linear(120, 6)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]

        # inits
        nn.init.xavier_uniform_(self.C.weight)
        nn.init.xavier_uniform_(self.J.weight)
        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.init_map.weight)
        nn.init.xavier_uniform_(self.head.weight); nn.init.zeros_(self.head.bias)

    @staticmethod
    def _sqrt_safe(x: torch.Tensor, eps: float) -> torch.Tensor:
        return torch.sqrt(x.clamp_min(0) + eps)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev, dtype = u_seq.device, u_seq.dtype

        # outputs
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # parameter streams
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01   # x0 is [m_obs0, p*0]
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # DNA total (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # teacher forcing slices
        y_mm = y_seq[:, :, 0:1]
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]

        # normalize u_seq once (used only for encoding/jumps)
        u_scale = (u_seq.abs().amax(dim=(0, 1), keepdim=True) + 1e-6)  # (1,1,U)
        u_seq_n = u_seq / u_scale

        # memory state and exp rates
        z = torch.zeros(B, self.m_s, device=dev, dtype=dtype)
        rate = F.softplus(self.lambda_mz_raw).unsqueeze(0)  # (1, m_s)

        # init logits from first-step features
        u0 = u_seq_n[:, 0]  # normalized
        feat0 = torch.cat([
            self._sqrt_safe(u0, self.EPS),
            self._sqrt_safe(mm_prev, self.EPS),
            self._sqrt_safe(pm_prev, self.EPS),
        ], dim=-1)
        h0 = self.lift(feat0)
        logits = self.init_map(h0).clamp(-self.LOGIT_CLIP, self.LOGIT_CLIP)

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]      # (B,1)
            u_k  = u_seq_n[:, k]         # (B,U) normalized for features/jumps

            # teacher forcing cadence
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if k == 0:
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev
            if (k % 100 == 0) and teacher_forcing:
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # features (unchanged structure)
            feat_k = torch.cat([
                self._sqrt_safe(u_k, self.EPS),
                self._sqrt_safe(det_mm, self.EPS),
                self._sqrt_safe(det_pm, self.EPS),
            ], dim=-1)
            h_k = self.lift(feat_k)

            # memory update
            decay = torch.exp((-rate * dt_k).to(torch.float32).clamp(min=-self.EXP_CAP)).to(dtype)  # (B,m_s)
            e_k = self._sqrt_safe(u_k, self.EPS)
            z = decay * z + self.C(logits) + self.J(e_k)
            z = z.clamp(-self.Z_CLIP, self.Z_CLIP)

            # logits update (bounded step + clipped logits)
            drift_in = torch.cat([logits, h_k, dt_k], dim=-1)
            d_logits = self.drift(drift_in)
            d_logits = torch.tanh(d_logits) * 0.5
            logits = logits + d_logits + 0.5 * self.W(z)
            logits = logits.clamp(-self.LOGIT_CLIP, self.LOGIT_CLIP)

            # head -> raw -> bounded θ via gamma
            z_head = self.bottle(logits)
            raw = self.head(z_head)  # <-- no head scaling, as requested
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw,   1e-6*0.5, 5e-4)
            VTXmax  = gamma(VTX_mag,   3e-5*0.5, 0.15)
            VTLmax  = gamma(VTL_mag,   3e-5*0.5, 0.1)
            kdm_k   = gamma(kdm_raw,   1e-5*0.5, 1e-2)
            kmt_k   = gamma(kmt_raw,   1e-5*0.5, 3.5e-4)
            kmatm_k = gamma(kmatm_raw, 5e-5*0.5, 3.5e-3)

            # analytic ODE step (unchanged)
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)
        return (out, params) if self.training else (out, params.detach())
    
class LinearRNN_model_latent_decay_simple_fb_mat(nn.Module):
    """
    Closed-loop, plain Linear RNN with state feedback (no bilinear modulation):
      input at step k: [u_k, sqrt(mm_{k-1}), sqrt(p*_{k-1})]
      -> lift(feat_k) -> B @ h_k drives LRNN latent with Δt-aware diagonal decay
      -> θ_k = [lam, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded via gamma)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,   # d: LRNN state size
                 d_h: int = 32,       # lift dimension for h_k
                 dropout: float = 0.0 # kept for API parity; not used on z
                 ):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h

        # in_dim = in_u + 2 (sqrt(mm_prev), sqrt(pm_prev))
        self.in_dim = in_u + 2

        # Small feature lift h_k = SiLU(W * feat_k)
        self.lift = nn.Sequential(
            nn.Linear(self.in_dim, d_h),
            nn.SiLU(),
        )

        # Linear drive into the LRNN latent: z_{k+1} = decay ⊙ z_k + B h_k
        self.B = nn.Linear(d_h, hidden, bias=False)

        # Per-neuron decay rates (learned, ≥0 via softplus)
        # Initialize near small positive to start with slow decay (A(Δt) ~ 1)
        self.lambda_raw = nn.Parameter(torch.full((hidden,), -2.0))

        # # Head stack (reused structure): bottle → head logits
        # self.bottle = nn.Sequential(
        #     nn.Linear(hidden, 120), nn.SiLU(),
        #     nn.Linear(120, 40), nn.SiLU(),
        # )
        self.head = nn.Linear(hidden, 6)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]

        # Inits
        nn.init.xavier_uniform_(self.B.weight)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0] (observed mature mRNA & mature protein*)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq  = torch.empty_like(mm_out)
        kdm_seq  = torch.empty_like(mm_out)
        VTL_seq  = torch.empty_like(mm_out)
        kmt_seq  = torch.empty_like(mm_out)
        kmatm_seq= torch.empty_like(mm_out)
        R_seq    = torch.empty_like(mm_out)
        lam_seq  = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01              # measured mature mRNA
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01              # NOTE: x0 provided as [m_obs0, p*0]
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # LRNN latent state
        z = torch.zeros(B, self.hidden, device=dev, dtype=dtype)

        # precompute positive rates
        lambda_pos = F.softplus(self.lambda_raw)  # (hidden,)

        # ground-truth slices for teacher forcing cadence
        y_mm = y_seq[:, :, 0:1]  # (B,K,1), mature mRNA
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]  # robust slice for p*

        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]      # (B,1)
            u_k   = u_seq[:, k]           # (B,U)

            # teacher forcing policy (unchanged)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if k == 0:
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev
            if (k % 50 == 0) and teacher_forcing:
                # use previous step ground truth if available
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # ---- feature construction (identical structure) ----
            feat_k = torch.cat([
                u_k,        # (B,U)
                torch.sqrt(det_mm).clamp_min(0),     # (B,1)
                torch.sqrt(det_pm).clamp_min(0),     # (B,1)
            ], dim=-1)  # (B, in_dim = U+2)

            # ---- Linear RNN core: z_{k+1} = exp(-λ Δt) ⊙ z_k + B h_k ----
            h_k = self.lift(feat_k)                        # (B, d_h)
            # broadcast elementwise decay to (B, hidden)
            decay = torch.exp(-lambda_pos.unsqueeze(0) * dt_k)  # (B, hidden)
            z = decay * z + self.B(h_k)                         # (B, hidden)

            # ---- head → raw params (reuse bottle/head) ----
            # z_head = self.bottle(z)
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            # ---- bounded θ via gamma (unchanged bounds) ----
            lam_k   = gamma(lam_raw,  1e-6, 5e-4)
            VTXmax  = gamma(VTX_mag,  3e-5, 0.12)
            VTLmax  = gamma(VTL_mag,  3e-5, 0.08)
            kdm_k   = gamma(kdm_raw,  1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw,  1e-5, 3.5e-4)
            kmatm_k = gamma(kmatm_raw,5e-5, 3.5e-3)

            # ---- one scripted ODE step (unchanged) ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store outputs
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            # store diagnostics (order preserved)
            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll biological states
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())
    
    

def safe_exp(x, max_mag: float = 40.0):
    # clamp to avoid inf; exp(±40) is already extreme.
    return torch.exp(x.clamp(min=-max_mag, max=max_mag))

class LinearRNN_model_latent_decay_simple_fb_matf(nn.Module):
    """
    Linear RNN with input-conditioned decay + low-rank bilinear term (safe version).
    Keeps the exact same input/output API and biological ODE step.
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 d_h: int = 32,
                 dropout: float = 0.0,
                 bilin_rank: int = 16,
                 bilin_init_scale: float = 0.1,   # small at start; can be increased/learned
                 enable_runtime_checks: bool = False):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h
        self.bilin_rank = bilin_rank
        self.enable_runtime_checks = enable_runtime_checks
        self.bilin_init_scale = bilin_init_scale

        # in_dim = in_u + 2 (sqrt(mm_prev), sqrt(pm_prev))
        self.in_dim = in_u + 2

        # feature lift
        self.lift = nn.Sequential(
            nn.Linear(self.in_dim, d_h),
            nn.SiLU(),
        )

        # linear drive
        self.B = nn.Linear(d_h, hidden, bias=False)

        # base decay (≥0 via softplus)
        self.lambda_raw = nn.Parameter(torch.full((hidden,), -2.0))
        
                # ===== Near-identity decay init (a0 = exp(-lambda0 * dt_ref)) =====
        a0 = float(max(min(0.997 , 0.999999), 0.9))   # safety: keep in (0,1)
        # dt_ref = float(max(1, 1e-8))         # avoid divide-by-zero
        
        lambda0 = -math.log(a0) 
        # inverse of softplus: s^{-1}(λ) = log(exp(λ) - 1) = logexpm1(λ)
        inv_softplus = 0.99
        with torch.no_grad():
            self.lambda_raw.fill_(inv_softplus)

        # input-conditioned decay gain (≥0 via softplus)
        self.lambda_mod = nn.Linear(d_h, hidden, bias=True)

        # bilinear low-rank coupling
        r = self.bilin_rank
        self.Wz = nn.Linear(hidden, r, bias=False)
        self.Wh = nn.Linear(d_h, r, bias=False)
        self.Wb_out = nn.Linear(r, hidden, bias=False)

        # head for raw params
        self.head = nn.Linear(hidden, 6)

        # init
        nn.init.xavier_uniform_(self.B.weight)
        nn.init.xavier_uniform_(self.head.weight); nn.init.zeros_(self.head.bias)
        nn.init.xavier_uniform_(self.lambda_mod.weight); nn.init.zeros_(self.lambda_mod.bias)
        for m in (self.Wz, self.Wh, self.Wb_out):
            nn.init.xavier_uniform_(m.weight)

        # optional: learnable scale on bilinear path (starts small to avoid bursts)
        self.bilin_scale = nn.Parameter(torch.tensor(self.bilin_init_scale), requires_grad=True)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype
        eps = 0
        # outputs
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)  

        # DNA cumulative
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # latent
        z = torch.zeros(B, self.hidden, device=dev, dtype=dtype)

        # base positive rates
        lambda_pos_base = F.softplus(self.lambda_raw)  # (hidden,)

        # ground truth slices
        y_mm = y_seq[:, :, 0:1]
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]


        for k in range(K):
            dt_k  = dt_seq[:, k:k+1]                    # (B,1)
            dt_k  = dt_k.clamp_min(eps)                 # avoid exactly 0

            u_k   = u_seq[:, k]                         # (B,U)

            # teacher forcing (safe for k=0)
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if teacher_forcing and (k > 0) and (k % 50 == 0):
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()
            
            # det_mm = det_mm.clamp_min(0.0)
            # det_pm = det_pm.clamp_min(0.0)


            # ---- SAFE feature construction (clamp BEFORE sqrt) ----
            feat_k = torch.cat([
                torch.sqrt(u_k),                                            # (B,U)
                torch.sqrt(det_mm + eps),        # (B,1)
                torch.sqrt(det_pm + eps),        # (B,1)
            ], dim=-1)  # (B, U+2)

            # lift
            h_k = self.lift(feat_k)                             # (B, d_h)

            # input-conditioned decay
            lambda_gain = F.softplus(self.lambda_mod(h_k))      # (B, hidden) >= 0
            lambda_eff  = lambda_pos_base.unsqueeze(0) + lambda_gain
            decay = safe_exp(-lambda_eff * dt_k)                # (B, hidden)

            # # low-rank bilinear
            bilin = self.Wb_out(self.Wz(z) * self.Wh(h_k))      # (B, hidden)
            bilin = self.bilin_scale * bilin

            # latent update
            z = decay * z + self.B(h_k) + bilin                 # (B, hidden)

            if self.enable_runtime_checks:
                assert torch.isfinite(z).all(), f"NaN/Inf in z at step {k}"

            # head → raw params
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            # bounded θ via gamma (unchanged)
            lam_k   = gamma(lam_raw,   1e-6, 5e-4)
            VTXmax  = gamma(VTX_mag,   3e-5, 0.12)
            VTLmax  = gamma(VTL_mag,   3e-5, 0.08)
            kdm_k   = gamma(kdm_raw,   1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw,   1e-5, 3.5e-4)
            kmatm_k = gamma(kmatm_raw, 5e-5, 3.5e-3)

            # ODE step
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            if self.enable_runtime_checks:
                for name, t in [
                    ("mm_curr", mm_curr), ("p_curr", p_curr),
                    ("pm_curr", pm_curr), ("R_curr", R_curr)
                ]:
                    assert torch.isfinite(t).all(), f"NaN/Inf in {name} at step {k}"

            # store outputs
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            # store diagnostics
            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll states
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)

        return (out, params) if self.training else (out, params.detach())
    
    


class GRU_model_latent_decay_simple_mat(nn.Module):
    def __init__(self, in_u: int,
                 hidden: int = 128,
                 num_layers: int = 1,
                 dropout:  float = 0.1):
        super().__init__()

        # GRU-1 (unchanged)
        self.gru1 = nn.GRU(in_u, hidden, batch_first=True,
                           num_layers=num_layers, dropout=dropout)
        # 5 outputs: [λ_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw]
        # bottleneck (unchanged)
        self.bottle = nn.Sequential(nn.Linear(hidden, 64), nn.SiLU(),
                                    nn.Linear(64,  32),    nn.SiLU())
        self.head1 = nn.Linear(32, 6)

    # ------------------------------------------------------------------
    def forward(self, x0, u_seq, dna_raw, dt_seq, y_seq:  torch.Tensor | None = None,):
        B, K, _ = u_seq.shape

        # ── first pass ────────────────────────────────────────────────
        h1, _ = self.gru1(u_seq)
        z = self.bottle(h1)
        raw1 = self.head1(z)                         # (B,K,5)

        # split channels
        lambda_raw1, VTX_mag1, kdm_raw1, VTL_mag1, kmt_raw1, kmt_m_raw_1 = raw1.split(1, -1)

        # Sample the lamdas
        lmd = gamma(lambda_raw1, 1e-6, 0.0005)
        VTX_max = gamma(VTX_mag1, 1e-4, 0.1)
        VTL_max = gamma(VTL_mag1, 1e-5, 0.08)
        kdm = gamma(kdm_raw1, 1e-5, 1e-2)
        kmt = gamma(kmt_raw1, 1e-6, 0.00035)
        kmt_m = gamma(kmt_raw1, 1e-6, 0.0035)
        
        x0 = torch.cat([x0, x0.new_ones((B, 1)), x0.new_zeros((B, 1))], dim=1)
        out_fin, params = integrate_vectors_analytical_R_mRNA_maturation(
            x0, dna_raw, dt_seq,
            VTX_max, kdm, VTL_max, kmt, kmt_m, lmd)



class GRU_model_latent_decay_simple_fb_matf(nn.Module):
    """
    Closed-loop model with Δt-aware GRU latent.
    Input at step k: [u_k, sqrt(mm_{k-1}), sqrt(p*_{k-1})] -> lift(feat_k)
    -> (decay hidden by exp(-λ Δt)) -> GRUCell -> z_k
    -> θ_k = [lam, VTX_max, kdm, VTL_max, kmt, kmatm] (bounded via gamma)
    -> ivtt_step_mRNA_maturation() -> next states

    Returns:
        out    : (B,K,3)  channels [mm, p, p*]
        params : (B,K,7)  [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(
        self,
        in_u: int,
        hidden: int = 128,  # GRU hidden size
        d_h: int = 32,      # lift dimension for h_k
        dropout: float = 0.01
    ):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h
        self.in_dim = in_u + 2  # [u_k, sqrt(mm_prev), sqrt(pm_prev)]

        # Small feature lift
        self.lift = nn.Sequential(
            nn.Linear(self.in_dim, d_h),
            nn.SiLU(),
            nn.Dropout(dropout) if dropout > 0 else nn.Identity(),
        )

        # Δt-aware decay on hidden is explicit (per-neuron λ ≥ 0 via softplus)
        # Init near small positive so exp(-λ Δt) ≈ 1 early on
        self.lambda_raw = nn.Parameter(torch.full((hidden,), -2.0))

        # GRU over lifted features; hidden is the latent
        self.gru = nn.GRUCell(input_size=d_h, hidden_size=hidden)

        # Head to raw params
        self.head = nn.Linear(hidden, 6)  # [lam, VTX_mag, kdm, VTL_mag, kmt, kmatm]

        # Inits
        for m in self.lift:
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight); nn.init.zeros_(m.bias)
        for name, param in self.gru.named_parameters():
            if "weight" in name:
                nn.init.xavier_uniform_(param)
            elif "bias" in name:
                nn.init.zeros_(param)
        nn.init.xavier_uniform_(self.head.weight)
        nn.init.zeros_(self.head.bias)

    def forward(
        self,
        x0: torch.Tensor,          # (B,2): [m_obs0, p*0]
        u_seq: torch.Tensor,       # (B,K,U)
        dna_raw: torch.Tensor,     # (B,K,1)
        dt_seq: torch.Tensor,      # (B,K)
        y_seq: torch.Tensor,       # (B,K,C) with mm at [:, :, 0], p* at [:, :, 2] or [:, :, 1]
        teacher_forcing: bool = True
    ) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs
        mm_out  = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out   = torch.empty_like(mm_out)
        pm_out  = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # cumulative DNA
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # latent state (GRU hidden)
        z = torch.zeros(B, self.hidden, device=dev, dtype=dtype)

        # positive per-neuron decay rates λ_i
        lambda_pos = F.softplus(self.lambda_raw)  # (hidden,)

        # ground-truth slices for occasional teacher forcing
        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]        # (B,1)
            u_k  = u_seq[:, k]             # (B,U)

            # teacher forcing cadence (safe at k=0)
            if teacher_forcing and k > 0 and (k % 50 == 0):
                det_mm = y_mm[:, k-1, :].detach()
                det_pm = y_pm[:, k-1, :].detach()
            else:
                det_mm = mm_prev.detach()
                det_pm = pm_prev.detach()

            # features
            feat_k = torch.cat([
                torch.sqrt(u_k),                                     # (B,U)
                torch.sqrt(det_mm).clamp_min(0),         # (B,1)
                torch.sqrt(det_pm).clamp_min(0),         # (B,1)
            ], dim=-1)                                   # (B, U+2)

            h_k = self.lift(feat_k)                      # (B, d_h)

            # ---- Δt-aware GRU update ----
            # decay hidden first, then apply GRUCell
            decay = torch.exp(-lambda_pos.unsqueeze(0) * dt_k)  # (B, hidden)
            z = self.gru(h_k, z)                        # (B, hidden)

            # ---- head -> raw params ----
            raw = self.head(z)
            lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            # ---- bounded θ via gamma ----
            lam_k  = gamma(lam_raw,   1e-6, 5e-4)
            VTXmax = gamma(VTX_mag,   3e-5, 0.12)
            VTLmax = gamma(VTL_mag,   3e-5, 0.08)
            kdm_k  = gamma(kdm_raw,   1e-5, 1e-2)
            kmt_k  = gamma(kmt_raw,   1e-5, 3.5e-4)
            kmatm_k= gamma(kmatm_raw, 5e-5, 3.5e-3)

            # ---- one scripted ODE step (unchanged) ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1, :]   = p_curr.unsqueeze(1)
            pm_out[:, k:k+1, :]   = pm_curr.unsqueeze(1)
            VTX_seq[:, k:k+1, :]  = VTXmax.unsqueeze(1)
            kdm_seq[:, k:k+1, :]  = kdm_k.unsqueeze(1)
            VTL_seq[:, k:k+1, :]  = VTLmax.unsqueeze(1)
            kmt_seq[:, k:k+1, :]  = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,   k:k+1, :]  = R_curr.unsqueeze(1)
            lam_seq[:, k:k+1, :]  = lam_k.unsqueeze(1)

            # roll biological states
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)
        return (out, params) if self.training else (out, params.detach())


# -------------------- Smooth bounded θ(t) head --------------------
class SmoothBoundedThetaHead(nn.Module):
    """
    Causal critically-damped 2nd-order smoother + affine-sigmoid bounds.
    Keeps per-parameter states (level s, velocity v) across the sequence.
    """
    def __init__(self, D_in: int, n_params: int, lows: torch.Tensor, highs: torch.Tensor):
        super().__init__()
        self.np = n_params

        # Fixed bounds (registered as buffers so they move with .to(device/dtype))
        self.register_buffer('lows',  lows.clone().detach())   # (np,)
        self.register_buffer('highs', highs.clone().detach())  # (np,)

        # z -> target r_k in (-1,1) per-parameter
        self.to_target = nn.Sequential(
            nn.Linear(D_in, 64), nn.SiLU(),
            nn.Linear(64, n_params)
        )

        # Positive dynamics parameters (shared across batch, per-parameter)
        self.omega_raw = nn.Parameter(torch.full((n_params,), 0.5))  # natural freq
        self.kappa_raw = nn.Parameter(torch.full((n_params,), 0.5))  # input gain

        # Runtime state (set in reset_state at start of each forward)
        self.register_buffer('s', torch.zeros(1, n_params))  # level
        self.register_buffer('v', torch.zeros(1, n_params))  # velocity

    @torch.jit.export
    def reset_state(self, B: int, ref: Optional[torch.Tensor] = None) -> None:
        """
        Reset s,v to zeros using device/dtype from `ref` if provided,
        otherwise from the existing buffers.
        """
        if ref is not None:
            dev = ref.device
            dtp = ref.dtype
        else:
            dev = self.s.device
            dtp = self.s.dtype
        self.s = torch.zeros((B, self.np), device=dev, dtype=dtp)
        self.v = torch.zeros((B, self.np), device=dev, dtype=dtp)
        
    def forward(self, z: torch.Tensor, dt_k: torch.Tensor) -> torch.Tensor:
        """
        z:   (B, D_in)
        dt_k:(B, 1)
        returns: theta_k (B, np) bounded to [lows, highs]
        """
        B = z.size(0)
        # Target signal in (-1,1)
        r = torch.tanh(self.to_target(z))                       # (B, np)

        # Critically-damped dynamics (ζ = 1), Euler step
        omega = F.softplus(self.omega_raw).unsqueeze(0).expand(B, -1) + 1e-4  # (B, np)
        kappa = F.softplus(self.kappa_raw).unsqueeze(0).expand(B, -1)         # (B, np)

        s, v = self.s, self.v
        dt   = dt_k  # (B,1) broadcasts

        # s_{k+1} = s_k + dt*v_k + kappa*dt*r_k
        s_next = s + dt * v + kappa * dt * r
        # v_{k+1} = v_k + dt*(-2 ω v_k - ω^2 s_k + ω^2 r_k)
        v_next = v + dt * (-2.0 * omega * v - (omega**2) * s + (omega**2) * r)

        self.s, self.v = s_next, v_next

        # Affine-sigmoid bounds to [lows, highs]
        sig = torch.sigmoid(s_next)                              # (B, np)
        theta = self.lows + (self.highs - self.lows) * sig       # (B, np)
        print(theta)
        return theta


# --------------- MZ core + smooth bounded θ(t) head ------------------
class MZ_model_latent_decay_simple_fb_matsmooth(nn.Module):
    """
    Mori–Zwanzig (memory + small drift) mapping u(t) -> smooth, bounded θ(t),
    then ivtt_step_mRNA_maturation() per step.

    Per-step features (unchanged):
        feat_k = [sqrt(u_k), sqrt(mm_{k-1}), sqrt(p*_{k-1})]

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 160,   # logits/latent width (raised a bit for 600 expts)
                 d_h: int = 32,       # feature-lift width
                 m_s: int = 20,       # memory atoms
                 dropout: float = 0.0):
        super().__init__()
        self.hidden = hidden
        self.d_h = d_h
        self.m_s = m_s

        # --- constants for numerics ---
        self.EPS = 1e-12
        self.EXP_CAP = 50.0      # clamp for exp(-x)
        self.LOGIT_CLIP = 50.0
        self.Z_CLIP = 1e6

        # Feature lift (same inputs as your GRU features)
        in_dim = in_u + 2
        self.lift = nn.Sequential(
            nn.Linear(in_dim, d_h),
            nn.SiLU(),
        )

        # MZ memory & couplings
        self.lambda_mz_raw = nn.Parameter(torch.linspace(-4.0, -1.0, m_s))  # softplus -> ≥0
        self.C = nn.Linear(hidden, m_s, bias=False)   # logits -> z
        self.J = nn.Linear(in_u,  m_s, bias=False)    # sqrt(u_norm) -> z
        self.W = nn.Linear(m_s,  hidden, bias=False)  # z -> logits

        # Small drift on logits
        self.drift = nn.Sequential(
            nn.Linear(hidden + d_h + 1, 64),
            nn.SiLU(),
            nn.Linear(64, hidden)
        )

        # Map first-step features to initial logits
        self.init_map = nn.Linear(d_h, hidden, bias=False)

        # Smooth bounded θ head (replaces gamma(head(...)))
        # Bounds correspond to your original gamma boxes:
        # order: [lam, VTX_max, kdm, VTL_max, kmt, kmatm]
        lows  = torch.tensor([1e-6, 3e-5, 1e-5, 3e-5, 1e-5, 5e-5])
        highs = torch.tensor([5e-4, 0.12, 1e-2, 0.08, 3.5e-4, 3.5e-3])
        self.theta_head = SmoothBoundedThetaHead(D_in=hidden, n_params=6, lows=lows, highs=highs)

        # Inits
        nn.init.xavier_uniform_(self.C.weight)
        nn.init.xavier_uniform_(self.J.weight)
        nn.init.xavier_uniform_(self.W.weight)
        nn.init.xavier_uniform_(self.init_map.weight)

    @staticmethod
    def _sqrt_safe(x: torch.Tensor, eps: float) -> torch.Tensor:
        return torch.sqrt(x.clamp_min(0) + eps)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev, dtype = u_seq.device, u_seq.dtype

        # outputs
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # parameter streams (in your required order)
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01   # x0 is [m_obs0, p*0]
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # DNA cumulative (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # teacher forcing views
        y_mm = y_seq[:, :, 0:1]
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]

        # normalize u_seq once for features/jumps
        u_scale = (u_seq.abs().amax(dim=(0, 1), keepdim=True) + 1e-6)  # (1,1,U)
        u_seq_n = u_seq / u_scale

        # MZ memory state & rates
        z = torch.zeros(B, self.m_s, device=dev, dtype=dtype)
        rate = F.softplus(self.lambda_mz_raw).unsqueeze(0)  # (1, m_s)

        # initialize logits and θ-head states
        u0 = u_seq_n[:, 0]
        feat0 = torch.cat([
            self._sqrt_safe(u0, self.EPS),
            self._sqrt_safe(mm_prev, self.EPS),
            self._sqrt_safe(pm_prev, self.EPS),
        ], dim=-1)
        h0 = self.lift(feat0)
        logits = self.init_map(h0).clamp(-self.LOGIT_CLIP, self.LOGIT_CLIP)

        # reset smoother state per batch
        self.theta_head.reset_state(B, ref = logits)

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]      # (B,1)
            u_k  = u_seq_n[:, k]         # (B,U) normalized

            # teacher forcing cadence
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if k == 0:
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev
            if (k % 100 == 0) and teacher_forcing:
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # features (unchanged structure)
            feat_k = torch.cat([
                self._sqrt_safe(u_k, self.EPS),
                self._sqrt_safe(det_mm, self.EPS),
                self._sqrt_safe(det_pm, self.EPS),
            ], dim=-1)
            h_k = self.lift(feat_k)

            # memory update
            decay = torch.exp((-rate * dt_k).to(torch.float32).clamp(min=-self.EXP_CAP)).to(dtype)  # (B,m_s)
            e_k = self._sqrt_safe(u_k, self.EPS)
            z = decay * z + self.C(logits) + self.J(e_k)
            z = z.clamp(-self.Z_CLIP, self.Z_CLIP)

            # logits update (bounded per-step + clip)
            drift_in = torch.cat([logits, h_k, dt_k], dim=-1)
            d_logits = self.drift(drift_in)
            d_logits = torch.tanh(d_logits) * 0.5
            logits = logits + d_logits + 0.5 * self.W(z)
            logits = logits.clamp(-self.LOGIT_CLIP, self.LOGIT_CLIP)

            # ---- smooth, bounded θ(t) (replaces gamma(head(...))) ----
            theta_k = self.theta_head(logits, dt_k)     # (B,6) in required bounds
            lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k = theta_k.split(1, dim=-1)

            # analytic ODE step (unchanged)
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store outputs
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            # store params in your order
            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll biological states
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)
        return (out, params) if self.training else (out, params.detach())
    
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional

# expects: ivtt_step_mRNA_maturation(...) defined elsewhere

# -------------------- Smooth bounded θ(t) head (log-space) --------------------
class SmoothBoundedThetaHead_Log(nn.Module):
    """
    Critically-damped 2nd-order smoother with backward-Euler (unconditionally stable)
    followed by a LOG-BOX bound:
        log θ = logL + (logH - logL) * sigmoid(s / T)   →  θ = exp(log θ)

    Per-parameter states: s (level), v (velocity).
    """
    def __init__(self, D_in: int, n_params: int,
                 lows: torch.Tensor, highs: torch.Tensor,
                 T_init: float = 2):
        super().__init__()
        self.np = n_params

        # Store linear-space bounds and their logs as buffers (move with .to())
        lows  = lows.clone().detach().clamp_min(1e-30)
        highs = highs.clone().detach().clamp_min(1e-30)
        self.register_buffer('lows',  lows)                      # (np,)
        self.register_buffer('highs', highs)                     # (np,)
        self.register_buffer('logL',  torch.log(lows))           # (np,)
        self.register_buffer('logH',  torch.log(highs))          # (np,)

        # Optional per-parameter temperature (keeps gradients well-scaled across decades)
        self.T_raw = nn.Parameter(torch.full((n_params,), float(T_init)))

        # z -> target r_k in (-1,1) per-parameter
        self.to_target = nn.Sequential(
            nn.Linear(D_in, 64), nn.SiLU(),
            nn.Linear(64, n_params)
        )

        # Positive dynamics parameter per θ_j (learned): ω_j
        self.omega_raw = nn.Parameter(torch.full((n_params,), 0.5))
        self.kappa_raw = nn.Parameter(torch.full((n_params,), 0.5))

        # Runtime states (initialized in reset_state)
        self.register_buffer('s', torch.zeros(1, n_params))  # level
        self.register_buffer('v', torch.zeros(1, n_params))  # velocity

    @torch.jit.export
    def reset_state(self, B: int, ref: Optional[torch.Tensor] = None) -> None:
        """TorchScript-friendly reset; `ref` provides device/dtype."""
        if ref is not None:
            dev, dtp = ref.device, ref.dtype
        else:
            dev, dtp = self.s.device, self.s.dtype
        self.s = torch.zeros((B, self.np), device=dev, dtype=dtp)
        self.v = torch.zeros((B, self.np), device=dev, dtype=dtp)

    def forward(self, z: torch.Tensor, dt_k: torch.Tensor) -> torch.Tensor:
        """
        z:    (B, D_in)
        dt_k: (B, 1)
        return: theta_k (B, n_params) within [lows, highs], smooth in time
        """
        B = z.size(0)
        # Target r in (-1,1)
        r = torch.tanh(self.to_target(z))                        # (B, np)

        # Backward-Euler update for critically-damped system (ζ=1)
        omega = F.softplus(self.omega_raw).unsqueeze(0).expand(B, -1)  # (B, np)
        kappa = F.softplus(self.kappa_raw).unsqueeze(0).expand(B, -1) + 1e-4 # (B, np) NEW
        dt    = dt_k                                                   # (B,1)
        alpha = omega * dt                                             # (B, np)
        denom = (1.0 + alpha)**2 + 1e-12                               # avoid /0

        s, v = self.s, self.v
        # y = x_k + dt * B r_k  with  A=[[0,1],[-ω^2,-2ω]], B=[[0],[ω^2]]
        y0 = s
        y1 = v + dt * (kappa * (omega**2)) * r

        # (I - dt*A)^{-1} y  with closed form:
        # M^{-1} = 1/denom * [[1+2α,  dt], [ -dt ω^2,  1 ]]
        s_next = ((1.0 + 2.0*alpha) * y0 + dt * y1) / denom
        v_next = (y1 - dt * (omega**2) * y0) / denom

        self.s, self.v = s_next, v_next

        # LOG-BOX mapping: log θ = logL + (logH - logL) * σ(s/T)
        T = F.softplus(self.T_raw).unsqueeze(0).expand_as(s_next)      # (B, np)
        sigma = torch.sigmoid(s_next / T)
        x = self.logL.unsqueeze(0) + (self.logH - self.logL).unsqueeze(0) * sigma
        theta = torch.exp(x)                                           # (B, np)
        return theta

class Transformer_model_latent_decay_simple_fb_matO(nn.Module):
    """
    Closed-loop causal Transformer encoder with state feedback:
      input at step k: [u_k, log1p/sqrt(mm_{k-1}), log1p/sqrt(p*_{k-1})]
      -> lift features
      -> causal Transformer over last `context_len` lifted feature vectors
      -> θ_k = [λ, λO, VTX_max, kdm, VTL_max, kmt, kmatm]  (bounded)
      -> ivtt_step_R_O_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,8) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam, lamO]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 128,
                 lift_dim: int = 32,
                 num_layers: int = 2,
                 dropout: float = 0.2,
                 ff_mult: int = 2,
                 context_len: int = 64):
        super().__init__()

        self.hidden = hidden
        self.num_layers = num_layers
        self.context_len = int(context_len)

        in_dim = in_u + 2

        self.lift = nn.Sequential(
            nn.Linear(in_dim, lift_dim),
            nn.SiLU(),
            nn.Linear(lift_dim, hidden),
        )

        self.pos_embed = nn.Embedding(self.context_len, hidden)

        nhead = max(1, hidden // 32)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden,
            nhead=nhead,
            dim_feedforward=hidden * ff_mult,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )

        self.transformer = nn.TransformerEncoder(
            encoder_layer,
            num_layers=max(1, num_layers),
            enable_nested_tensor=False,
        )

        self.bottle = nn.Sequential(
            nn.Linear(hidden, 128),
            nn.SiLU(),
            nn.Linear(128, 64),
            nn.SiLU(),
        )

        self.head = nn.Linear(64, 7)

        self.register_buffer(
            "_causal_mask",
            nn.Transformer.generate_square_subsequent_mask(self.context_len),
            persistent=False,
        )

        nn.init.normal_(self.head.weight, std=0.01)
        nn.init.zeros_(self.head.bias)

        nn.init.normal_(self.pos_embed.weight, std=0.02)

    def forward(self,
                x0:      torch.Tensor,   # (B,3): [m_obs0, p0, p*0]  (obs mRNA is matured)
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs (we return mm, p, pm)
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostics
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)
        lamO_seq  = torch.empty_like(mm_out)

        mm_prev = x0[:, 0:1] + 0.01                 # measured mRNA is mature
        m_prev  = torch.zeros_like(mm_prev) + 0.01  # start immature m at 0
        pm_prev = x0[:, 2:3] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)
        O_prev  = torch.ones_like(mm_prev)

        # constant DNA per sequence (matches integrator)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        y_mm = y_seq[:, :, 0:1]  # (B,K,1)
        y_pm = y_seq[:, :, 2:3]  # (B,K,1)

        feat_history: List[torch.Tensor] = []

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]      # (B,1)
            u_k  = u_seq[:, k]           # (B,U)

            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev

            if k == 0:
                # for step 0, use the provided initial obs x0
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev

            if k % 200 == 0 and teacher_forcing == True:
                # use ground-truth from previous step if available
                mm_gt_prev = y_mm[:, k - 1, :]
                pm_gt_prev = y_pm[:, k - 1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            feat_k = torch.cat(
                [
                    torch.sqrt(u_k).clamp_min(0),
                    torch.sqrt(det_mm).clamp_min(1),
                    torch.sqrt(det_pm).clamp_min(1),
                    # torch.sqrt(R_prev),
                    # torch.sqrt(O_prev),
                ],
                dim=-1,
            )  # (B, in_dim)

            feat = self.lift(feat_k)  # (B, hidden)
            feat_history.append(feat)

            # detach features that have scrolled out of the context window
            if len(feat_history) > self.context_len:
                feat_history[-self.context_len - 1] = (
                    feat_history[-self.context_len - 1].detach()
                )

            start = max(0, len(feat_history) - self.context_len)
            window: List[torch.Tensor] = feat_history[start:]
            W = len(window)

            seq = torch.stack(window, dim=1)  # (B, W, hidden)

            # window-relative positional embedding: 0 = oldest, W-1 = newest
            pos_ids = torch.arange(W, device=dev, dtype=torch.long)
            seq = seq + self.pos_embed(pos_ids).unsqueeze(0)

            mask = self._causal_mask[:W, :W].to(device=dev, dtype=seq.dtype)

            trans_out = self.transformer(seq, mask=mask, is_causal=True)
            h = trans_out[:, -1, :]  # (B, hidden)

            # head → raw params
            z = self.bottle(h)
            raw = self.head(z)

            lam_raw, lamO_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw, kmatm_raw = raw.split(1, dim=-1)

            lam_k   = gamma(lam_raw, 1e-6, 0.0005)
            lam_O   = gamma(lamO_raw, 1e-6, 0.0005)
            VTXmax  = gamma(VTX_mag, 5e-5, 0.1)
            VTLmax  = gamma(VTL_mag, 5e-5, 0.06)
            kdm_k   = gamma(kdm_raw, 1e-5, 1e-2)
            kmt_k   = gamma(kmt_raw, 1e-5, 0.00035)
            kmatm_k = gamma(kmatm_raw, 5e-5, 0.0035)

            # ---- one scripted step ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr = ivtt_step_R_O_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev,
                dt_k, dna_cum_total,
                lam_k, lam_O, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store
            mm_out[:, k:k+1, :] = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1, :] = p_curr.unsqueeze(1)
            pm_out[:, k:k+1, :] = pm_curr.unsqueeze(1)

            VTX_seq[:,   k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,   k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,   k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,   k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:, k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,     k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,   k:k+1, :] = lam_k.unsqueeze(1)
            lamO_seq[:,  k:k+1, :] = lam_O.unsqueeze(1)

            # roll
            m_prev, mm_prev, p_prev, pm_prev, R_prev, O_prev = (
                m_curr, mm_curr, p_curr, pm_curr, R_curr, O_curr
            )

        out = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3): [mm, p, p*]

        params = torch.cat(
            [VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq, lamO_seq],
            dim=-1,
        )  # (B,K,8)

        return (out, params) if self.training else (out, params.detach())
    
# --------------- Closed-loop stacked-GRU + smooth log-box θ(t) head ---------------
class GRU_model_latent_decay_simple_fb_mat_smooth_log(nn.Module):
    """
    Same as your GRU model, but θ(t) is produced by a stable smoother in LOG-SPACE.
      input at step k: [sqrt(u_k), sqrt(mm_{k-1}), sqrt(p*_{k-1})]
      -> stacked GRUCells
      -> bottle (Linear+SiLU x2)
      -> SmoothBoundedThetaHead_Log (critically damped, BE, log-box)
      -> ivtt_step_mRNA_maturation() -> states for next step

    Returns:
      out    : (B,K,3) with channels [mm, p, p*]
      params : (B,K,7) with [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam]
    """
    def __init__(self,
                 in_u: int,
                 hidden: int = 200,
                 num_layers: int = 2,
                 dropout: float = 0.2):
        super().__init__()
        assert num_layers >= 1
        self.hidden = hidden
        self.num_layers = num_layers
        self.EPS = 1e-6

        in_dim = in_u + 2  # sqrt(mm_prev), sqrt(pm_prev)

        # GRU stack (unchanged)
        cells = [nn.GRUCell(in_dim, hidden)]
        cells += [nn.GRUCell(hidden, hidden) for _ in range(num_layers - 1)]
        self.cells = nn.ModuleList(cells)
        self.dropout = nn.Dropout(dropout)

        # Bottle (unchanged)
        self.bottle = nn.Sequential(
            nn.Linear(hidden, int(hidden/2)), nn.SiLU(),
            nn.Linear(int(hidden/2), int(hidden/4)), nn.SiLU(),
        )
        bottle_out_dim = int(hidden/4)

        # Smooth θ head in LOG-SPACE (order: [lam, VTX_max, kdm, VTL_max, kmt, kmatm])
        lows  = torch.tensor([1e-6, 3e-5, 1e-5, 3e-5, 1e-5, 5e-5])
        highs = torch.tensor([5e-4, 0.1, 1e-2, 0.15, 3.5e-4, 3.5e-3])
        self.theta_head = SmoothBoundedThetaHead_Log(D_in=bottle_out_dim, n_params=6,
                                                     lows=lows, highs=highs, T_init=2.0)

        # Inits (as in your GRU)
        for c in self.cells:
            nn.init.orthogonal_(c.weight_hh)
            nn.init.xavier_uniform_(c.weight_ih)
            nn.init.zeros_(c.bias_hh)
            nn.init.zeros_(c.bias_ih)

    @staticmethod
    def _feat(u_k: torch.Tensor, mm: torch.Tensor, pm: torch.Tensor, eps: float) -> torch.Tensor:
        # exact same features, but numerically safe sqrt
        return torch.cat([
            u_k.clamp_min(0) + eps,
            mm.clamp_min(0) + eps,
            pm.clamp_min(0) + eps,
        ], dim=-1)

    def forward(self,
                x0:      torch.Tensor,   # (B,2): [m_obs0, p*0]
                u_seq:   torch.Tensor,   # (B,K,U)
                dna_raw: torch.Tensor,   # (B,K,1)
                dt_seq:  torch.Tensor,   # (B,K)
                y_seq:   torch.Tensor,
                teacher_forcing: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:

        B, K, U = u_seq.shape
        dev = u_seq.device
        dtype = u_seq.dtype

        # outputs
        mm_out = torch.empty(B, K, 1, device=dev, dtype=dtype)
        p_out  = torch.empty_like(mm_out)
        pm_out = torch.empty_like(mm_out)

        # diagnostic params (order: [VTX_max, kdm, VTL_max, kmt, kmatm, R, lam])
        VTX_seq   = torch.empty_like(mm_out)
        kdm_seq   = torch.empty_like(mm_out)
        VTL_seq   = torch.empty_like(mm_out)
        kmt_seq   = torch.empty_like(mm_out)
        kmatm_seq = torch.empty_like(mm_out)
        R_seq     = torch.empty_like(mm_out)
        lam_seq   = torch.empty_like(mm_out)

        # initial biological states
        mm_prev = x0[:, 0:1] + 0.01
        m_prev  = torch.zeros_like(mm_prev) + 0.01
        pm_prev = x0[:, 1:2] + 0.01
        p_prev  = torch.zeros_like(mm_prev) + 0.01
        R_prev  = torch.ones_like(mm_prev)

        # DNA cumulative (matches integrator expectations)
        dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

        # GRU hidden init
        hs = [torch.zeros(B, self.hidden, device=dev, dtype=dtype) for _ in range(self.num_layers)]

        # teacher-forcing targets
        y_mm = y_seq[:, :, 0:1]
        y_pm = y_seq[:, :, 2:3] if y_seq.shape[-1] >= 3 else y_seq[:, :, 1:2]

        # # Optional: normalize u once for encoding stability (keeps feature range tame)
        u_scale = (u_seq.abs().amax(dim=(0, 1), keepdim=True) + 1e-6)
        u_seq_n = u_seq
    
        # reset smoother state for this batch/sequence (use ref tensor for device/dtype)
        self.theta_head.reset_state(B, ref=u_seq)

        for k in range(K):
            dt_k = dt_seq[:, k:k+1]  # (B,1)
            u_k  = u_seq_n[:, k]     # (B,U) normalized for features

            # teacher forcing cadence
            mm_gt_prev = mm_prev
            pm_gt_prev = pm_prev
            if k == 0:
                mm_gt_prev = mm_prev
                pm_gt_prev = pm_prev
            if (k % 25 == 0) and teacher_forcing:
                mm_gt_prev = y_mm[:, k-1, :]
                pm_gt_prev = y_pm[:, k-1, :]

            det_mm = mm_gt_prev.detach()
            det_pm = pm_gt_prev.detach()

            # ---- features (unchanged structure) ----
            feat_k = self._feat(u_k, torch.sqrt(det_mm+1), torch.sqrt(det_pm+1), self.EPS)  # (B, in_dim)

            # ---- GRU core (unchanged) ----
            x = feat_k
            for li, cell in enumerate(self.cells):
                hs[li] = cell(x, hs[li])
                x = self.dropout(hs[li]) if self.training else hs[li]
            h = x  # (B, hidden)

            # ---- bottle -> smooth bounded log-box θ(t) ----
            z = self.bottle(h)                                   # (B, 40)
            theta_k = self.theta_head(z, dt_k)                   # (B, 6) in [L,H] (log-space box)
            lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k = theta_k.split(1, dim=-1)

            # ---- analytic ODE step (unchanged) ----
            m_curr, mm_curr, p_curr, pm_curr, R_curr = ivtt_step_mRNA_maturation(
                m_prev, mm_prev, p_prev, pm_prev, R_prev,
                dt_k, dna_cum_total,
                lam_k, VTXmax, kdm_k, VTLmax, kmt_k, kmatm_k
            )

            # store outputs
            mm_out[:, k:k+1, :]   = mm_curr.unsqueeze(1)
            p_out[:,  k:k+1,  :]  = p_curr.unsqueeze(1)
            pm_out[:, k:k+1,  :]  = pm_curr.unsqueeze(1)

            # store diagnostic params (order preserved)
            VTX_seq[:,  k:k+1, :] = VTXmax.unsqueeze(1)
            kdm_seq[:,  k:k+1, :] = kdm_k.unsqueeze(1)
            VTL_seq[:,  k:k+1, :] = VTLmax.unsqueeze(1)
            kmt_seq[:,  k:k+1, :] = kmt_k.unsqueeze(1)
            kmatm_seq[:,k:k+1, :] = kmatm_k.unsqueeze(1)
            R_seq[:,    k:k+1, :] = R_curr.unsqueeze(1)
            lam_seq[:,  k:k+1, :] = lam_k.unsqueeze(1)

            # roll biological states
            m_prev, mm_prev, p_prev, pm_prev, R_prev = m_curr, mm_curr, p_curr, pm_curr, R_curr

        out    = torch.cat([mm_out, p_out, pm_out], dim=-1)  # (B,K,3)
        params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, kmatm_seq, R_seq, lam_seq], dim=-1)  # (B,K,7)
        return (out, params) if self.training else (out, params.detach())

#         return (out_fin, params.detach()) if self.training else (out_fin, params.detach())
# 
# class GRU_model_latent_decay(nn.Module):
#     def __init__(self, in_u: int,
#                  hidden: int = 128,
#                  num_layers: int = 1,
#                  dropout:  float = 0.1):
#         super().__init__()

#         # GRU-1 (unchanged)
#         self.gru1 = nn.GRU(in_u, hidden, batch_first=True,
#                            num_layers=num_layers, dropout=dropout)
#         # 5 outputs: [λ_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw]
#         self.head1 = nn.Linear(hidden, 5)

#         # bottleneck (unchanged)
#         self.bottle = nn.Sequential(nn.Linear(hidden, 64), nn.SiLU(),
#                                     nn.Linear(64,  8),    nn.SiLU())

#         # GRU-2 (unchanged)
#         in2 = 8 + 3
#         self.gru2 = nn.GRU(in2, 64, batch_first=True,
#                            num_layers=num_layers, dropout=dropout)
#         self.head2 = nn.Linear(64, 5)          # same 5-channel layout

#     # ------------------------------------------------------------------
#     def forward(self, x0, u_seq, dna_raw, dt_seq, y_seq:  torch.Tensor | None = None,):
#         B, K, _ = u_seq.shape

#         # ── first pass ────────────────────────────────────────────────
#         h1, _ = self.gru1(u_seq)
#         z = self.bottle(h1)
#         raw1 = self.head1(h1)                         # (B,K,5)

#         # split channels
#         lambda_raw1, VTX_mag1, kdm_raw1, VTL_mag1, kmt_raw1 = raw1.split(1, -1)
#         # λ : map to [0, 1e-3]  (allow almost-zero decay)
#         # λ : map to [0, 1e-3]  (allow almost-zero decay)
#         lmd = gamma(lambda_raw1, 1e-6, 0.0005)
#         VTX_max = gamma(VTX_mag1, 1e-5, 0.1)
#         VTL_max = gamma(VTL_mag1, 1e-5, 0.066)
#         kdm = gamma(kdm_raw1, 1e-5, 1e-2)
#         kmt = gamma(kmt_raw1, 1e-6, 0.00015)
        
#         x0 = torch.cat([x0, x0.new_ones((B, 1))], dim=1)
#         out, _ = integrate_vectors_analytical_R(
#             x0, dna_raw, dt_seq,
#             VTX_max, kdm, VTL_max, kmt, lmd)

#         # ── second pass (refiner) ─────────────────────────────────────
#         ctrl = torch.cat([z, torch.log1p(out)], dim=-1)
#         h2, _ = self.gru2(ctrl)
#         raw2 = self.head2(h2)                         # (B,K,5)

#         lambda_raw1, VTX_mag1, kdm_raw1, VTL_mag1, kmt_raw1 = raw2.split(1, -1)

#         # λ : map to [0, 1e-3]  (allow almost-zero decay)
#         lmd = gamma(lambda_raw1, 1e-6, 0.0005)
#         VTX_max = gamma(VTX_mag1, 1e-4, 0.08)
#         VTL_max = gamma(VTL_mag1, 1e-5, 0.04)
#         kdm = gamma(kdm_raw1, 1e-4, 1e-2)
#         kmt = gamma(kmt_raw1, 1e-5, 0.005)


#         out_fin, params = integrate_vectors_analytical_R(
#             x0, dna_raw, dt_seq,
#             VTX_max, kdm, VTL_max, kmt, lmd)

#         return (out_fin, params.detach()) if self.training else (out_fin, params.detach())



# class LSTM_model_latent_decay(nn.Module):
#     def __init__(self, in_u: int,
#                  hidden: int = 128,
#                  num_layers: int = 1,
#                  dropout:  float = 0.1):
#         super().__init__()

#         # GRU-1 (unchanged)
#         self.gru1 = nn.LSTM(in_u, hidden, batch_first=True,
#                            num_layers=num_layers, dropout=dropout)
#         # 5 outputs: [λ_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw]
#         self.head1 = nn.Linear(hidden, 5)

#         # bottleneck (unchanged)
#         self.bottle = nn.Sequential(nn.Linear(hidden, 32), nn.SiLU(),
#                                     nn.Linear(32,  8),    nn.SiLU())

#         # GRU-2 (unchanged)
#         in2 = 8 + 3
#         self.gru2 = nn.LSTM(in2, 64, batch_first=True,
#                            num_layers=num_layers, dropout=0.)
#         self.head2 = nn.Linear(64, 5)          # same 5-channel layout

#     # ------------------------------------------------------------------
#     def forward(self, x0, u_seq, dna_raw, dt_seq, y_seq:  torch.Tensor | None = None,):
#         B, K, _ = u_seq.shape

#         # ── first pass ────────────────────────────────────────────────
#         h1, _ = self.gru1(u_seq)
#         z = self.bottle(h1)
#         raw1 = self.head1(h1)                         # (B,K,5)

#         # split channels
#         lambda_raw1, VTX_mag1, kdm_raw1, VTL_mag1, kmt_raw1 = raw1.split(1, -1)
#         # λ : map to [0, 1e-3]  (allow almost-zero decay)

#         lmd = gamma(lambda_raw1, 1e-6, 0.0005)
#         VTX_max = gamma(VTX_mag1, 1e-5, 0.1)
#         VTL_max = gamma(VTL_mag1, 1e-5, 0.066)
#         kdm = gamma(kdm_raw1, 1e-5, 1e-2)
#         kmt = gamma(kmt_raw1, 1e-6, 0.00015)
#         x0 = torch.cat([x0, x0.new_ones((B, 1))], dim=1)
#         out, _ = integrate_vectors_analytical_R(
#             x0, dna_raw, dt_seq,
#             VTX_max, kdm, VTL_max, kmt, lmd)

#         # ── second pass (refiner) ─────────────────────────────────────
#         ctrl = torch.cat([z, torch.log1p(out)], dim=-1)
#         h2, _ = self.gru2(ctrl)
#         raw2 = self.head2(h2)                         # (B,K,5)

#         lambda_raw1, VTX_mag1, kdm_raw1, VTL_mag1, kmt_raw1 = raw2.split(1, -1)

#         # λ : map to [0, 1e-3]  (allow almost-zero decay)
#         lmd = gamma(lambda_raw1, 1e-6, 0.0005)
#         VTX_max = gamma(VTX_mag1, 1e-5, 0.1)
#         VTL_max = gamma(VTL_mag1, 1e-5, 0.066)
#         kdm = gamma(kdm_raw1, 1e-5, 1e-2)
#         kmt = gamma(kmt_raw1, 1e-6, 0.00015)

#         out_fin, params = integrate_vectors_analytical_R(
#             x0, dna_raw, dt_seq,
#             VTX_max, kdm, VTL_max, kmt, lmd)

#         return (out_fin, params.detach()) if self.training else (out_fin, params.detach())
    
# ###############################################################################
# # Common imports
# ###############################################################################
# import math
# from typing import Optional, List
# import torch
# import torch.nn as nn
# import torch.nn.functional as F

# ###############################################################################
# # 1) Streaming-Transformer – two-pass
# ###############################################################################
# class StreamingTransformer_model_vectorized(nn.Module):
#     def __init__(self,
#                  in_u: int,
#                  hidden: int = 128,
#                  nhead: int = 8,
#                  num_layers: int = 4,
#                  dropout: float = 0.1,
#                  max_len: int = 30_000):
#         super().__init__()
#         self.embed = nn.Linear(in_u, hidden)
#         self.pe    = nn.Parameter(torch.randn(1, max_len, hidden))   # learned PE

#         enc_layer  = nn.TransformerEncoderLayer(hidden, nhead,
#                                                 4 * hidden,
#                                                 dropout,
#                                                 batch_first=True)
#         self.enc1  = nn.TransformerEncoder(enc_layer, num_layers)
#         self.enc2  = self.enc1                                         # weight-tied
#         self.head1 = nn.Linear(hidden, 6)
#         self.head2 = nn.Linear(hidden, 6)

#     # ------------------------------------------------------------------
#     def forward(
#         self,
#         x0:      torch.Tensor,
#         u_seq:   torch.Tensor,   # (B,K,U)
#         dna_raw: torch.Tensor,
#         dt_seq:  torch.Tensor,   # (B,K)
#         y_seq:   Optional[torch.Tensor] = None
#     ):
#         B, K, _ = u_seq.shape
#         mask = torch.full((K, K), float('-inf'), device=u_seq.device).triu(1)

#         # ---------- pass 1 --------------------------------------------------
#         h1 = self.enc1(self.embed(u_seq) + self.pe[:, :K], mask)
#         raw1 = self.head1(h1)

#         VTX_raw, VTX_mag, kdm_raw, VTL_raw, VTL_mag, kmt_raw = raw1.chunk(6, -1)
#         VTX_max = 1e-4 + (2e-2 - 1e-4) * torch.sigmoid(VTX_mag)
#         VTL_max = 1e-5 + (2e-2 - 1e-5) * torch.sigmoid(VTL_mag)
#         kdm     = 1e-4 + (1e-2 - 1e-4) * torch.sigmoid(kdm_raw)
#         kmt     = 1e-6 + (1e-3 - 1e-6) * torch.sigmoid(kmt_raw)

#         out1, _ = integrate_three_state_with_gates_fixed(
#             build_x0_ext_on(x0), dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         # ---------- pass 2 --------------------------------------------------
#         ctrl2 = torch.cat([u_seq, out1], -1)
#         h2 = self.enc2(self.embed(ctrl2) + self.pe[:, :K], mask)
#         raw2 = self.head2(h2)

#         VTX_raw, VTX_mag, kdm_raw, VTL_raw, VTL_mag, kmt_raw = raw2.chunk(6, -1)
#         VTX_max = 1e-4 + (2e-2 - 1e-4) * torch.sigmoid(VTX_mag)
#         VTL_max = 1e-5 + (2e-2 - 1e-5) * torch.sigmoid(VTL_mag)
#         kdm     = 1e-4 + (1e-2 - 1e-4) * torch.sigmoid(kdm_raw)
#         kmt     = 1e-6 + (1e-3 - 1e-6) * torch.sigmoid(kmt_raw)

#         out2, params = integrate_three_state_with_gates_fixed(
#             build_x0_ext_on(x0), dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         return out2 if self.training else (out2, params.detach())

# # -----------------------------------------------------------------------------
# # 1) Model Definition: This is the lstm model
# # -----------------------------------------------------------------------------
# class GRU_model(nn.Module):
#     def __init__(self, in_u: int,
#                  hidden: int = 64,
#                  num_layers: int = 2,
#                  dropout: float = 0.1):
#         super().__init__()

#         self.lstm = nn.GRU(in_u,
#                            hidden,
#                            batch_first=True,
#                            num_layers=num_layers,
#                            dropout=dropout)
#         self.lstm_x = nn.GRU(in_u + 3,
#                              hidden,
#                              batch_first=True,
#                              num_layers=num_layers,
#                              dropout=dropout)
#         self.head = nn.Linear(hidden, 6)
#         self.head_x = nn.Linear(hidden, 6)

#     # ------------------------------------------------------------------

#     def forward(self, x0:     torch.Tensor,   # (B,2)
#                 u_seq:  torch.Tensor,   # (B,K,U)
#                 dna_raw: torch.Tensor,
#                 dt_seq: torch.Tensor,   # (B,K)
#                 y_seq:  torch.Tensor | None = None,
#                 ):
#         # raw network outputs
#         B, K, U = u_seq.shape
#         B, K, U = u_seq.shape
#         dt = dt_seq[:, 0:1]                         # scalar (B,1)

#         # ---------- absolute time embedding ----------
#         t_abs = torch.arange(K, device=u_seq.device).unsqueeze(0) * dt  # (B,K)
#         t_feat = fourier_encode(
#             t_abs, n_freq=4)                        # (B,K,8)

#         # ---------- pass 1 ----------
#         inp1 = torch.cat([u_seq], -1)              # (B,K,U+8)
#         lstm_out, _ = self.lstm(inp1)        # (B,K,H)
#         raw = self.head(lstm_out)             # (B,K,6)

#         VTX_raw, VTX_mag_raw, kdm_raw, VTL_raw, VTL_mag_raw, kmt_raw = raw.chunk(
#             6, dim=-1)

#         # map to ranges
#         VTX_max = gamma(VTX_mag_raw, 1e-5, 0.066)
#         VTL_max = gamma(VTL_mag_raw, 1e-5, 0.03)
#         kdm = gamma(kdm_raw, 1e-4, 1e-2)
#         kmt = gamma(kmt_raw, 1e-6, 1e-2)
#         x0_ext = build_x0_ext_on(x0)

#         out, params = integrate_vectors_analytical(
#             x0_ext,          # (B,5) – includes initial hTX, hTL (e.g. zeros)
#             dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         ctrl = torch.cat([u_seq, out], -1)      # (B,K,U+2)
#         lstm_out, _ = self.lstm_x(ctrl)
#         raw = self.head_x(lstm_out)             # (B,K,6)

#         VTX_raw, VTX_mag_raw, kdm_raw, VTL_raw, VTL_mag_raw, kmt_raw = raw.chunk(
#             6, dim=-1)

#         # map to ranges
#         VTX_max = gamma(VTX_mag_raw, 1e-5, 0.066)
#         VTL_max = gamma(VTL_mag_raw, 1e-5, 0.03)
#         kdm = gamma(kdm_raw, 1e-4, 1e-2)
#         kmt = gamma(kmt_raw, 1e-6, 1e-2)
#         x0_ext = build_x0_ext_on(x0)
#         out, params = integrate_vectors_analytical(
#             x0_ext,          # (B,5) – includes initial hTX, hTL (e.g. zeros)
#             dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)                 # same weights!

#         return out if self.training else (out, params.detach())


# # -----------------------------------------------------------------------------
# class GRU_model_latent(nn.Module):
#     def __init__(self, in_u: int,
#                  hidden: int = 128,
#                  num_layers: int = 1,
#                  dropout: float = 0.1):
#         super().__init__()

#         # ── 1️⃣  GRU-1 (coarse θ) 128 hidden ─────────────────────────────
#         self.gru1 = nn.GRU(in_u,
#                            hidden,
#                            batch_first=True,
#                            num_layers=num_layers,
#                            dropout=dropout)
#         self.head1 = nn.Linear(hidden, 6)

#         # ── 2️⃣  Bottleneck block: 128 → 64 → 8 ─────────────────────────
#         self.bottle = nn.Sequential(
#             nn.Linear(hidden, 64),  nn.SiLU(),      # 128 → 64
#             nn.Linear(64,  8),      nn.SiLU())      # 64  →  8  (zₖ)

#         # ── 3️⃣  GRU-2 (refiner) takes the 8-d z + extras ───────────────
#         in2 = 8 + 3           # zₖ  +  log(m) + log(p*)
#         self.gru2 = nn.GRU(in2,
#                            64,                 # hidden width fixed at 64
#                            batch_first=True,
#                            num_layers=num_layers,       # single layer
#                            dropout=dropout)        # no dropout for depth 1
#         self.head2 = nn.Linear(64, 6)

#     # ------------------------------------------------------------------

#     def forward(self, x0:     torch.Tensor,   # (B,2)
#                 u_seq:  torch.Tensor,   # (B,K,U)
#                 dna_raw: torch.Tensor,
#                 dt_seq: torch.Tensor,   # (B,K)
#                 y_seq:  torch.Tensor | None = None,
#                 ):
#         # raw network outputs
#         B, K, U = u_seq.shape
#         B, K, U = u_seq.shape
#         dt = dt_seq[:, 0:1]                         # scalar (B,1)

#         # ---------- pass 1 ----------
#         inp1 = torch.cat([u_seq], -1)              # (B,K,U+8)
#         h1, _ = self.gru1(inp1)          # (B,K,128)
#         z = self.bottle(h1)          # (B,K,8)
#         raw = self.head1(h1)
#         # … run coarse solver to get log(m), log(p*)

#         VTX_raw, VTX_mag_raw, kdm_raw, VTL_raw, VTL_mag_raw, kmt_raw = raw.chunk(
#             6, dim=-1)

#         # map to ranges
#         VTX_max = gamma(VTX_mag_raw, 1e-5, 0.1)
#         VTL_max = gamma(VTL_mag_raw, 1e-5, 0.03)
#         kdm = gamma(kdm_raw, 1e-4, 1e-2)
#         kmt = gamma(kmt_raw, 1e-6, 1e-2)
#         x0_ext = build_x0_ext_on(x0)

#         out, params = integrate_vectors_analytical(
#             x0_ext,          # (B,5) – includes initial hTX, hTL (e.g. zeros)
#             dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         ctrl = torch.cat([z, out], -1)   # (B,K,10)
#         h2, _ = self.gru2(ctrl)                    # (B,K,64)
#         raw = self.head2(h2)                     # (B,K,6)

#         VTX_raw, VTX_mag_raw, kdm_raw, VTL_raw, VTL_mag_raw, kmt_raw = raw.chunk(
#             6, dim=-1)

#         # map to ranges
#         VTX_max = gamma(VTX_mag_raw, 1e-5, 0.1)
#         VTL_max = gamma(VTL_mag_raw, 1e-5, 0.03)
#         kdm = gamma(kdm_raw, 1e-4, 1e-2)
#         kmt = gamma(kmt_raw, 1e-6, 1e-2)
#         x0_ext = build_x0_ext_on(x0)
#         out, params = integrate_vectors_analytical(
#             x0_ext,          # (B,5) – includes initial hTX, hTL (e.g. zeros)
#             dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)                 # same weights!

#         return out if self.training else (out, params.detach())


# ###############################################################################
# # 2) Conditional Flow-Matching Network
# ###############################################################################
# class FlowMatching_model_vectorized(nn.Module):
#     def __init__(self, in_u: int, hidden: int = 128, layers: int = 4):
#         super().__init__()
#         self.ctrl   = nn.Linear(in_u, hidden)

#         mlp_blocks = []
#         for _ in range(layers):
#             mlp_blocks += [nn.Linear(hidden, hidden), nn.SiLU()]
#         self.drift  = nn.Sequential(*mlp_blocks)      # g_φ in hidden-space

#         self.param_head = nn.Linear(hidden, 6)        # θ₀
#         self.vel_head   = nn.Linear(hidden, 6)        # Δθ/Δt

#     # ------------------------------------------------------------------
#     def forward(
#         self,
#         x0:      torch.Tensor,
#         u_seq:   torch.Tensor,    # (B,K,U)
#         dna_raw: torch.Tensor,
#         dt_seq:  torch.Tensor,    # (B,K)
#         y_seq:   Optional[torch.Tensor] = None
#     ):
#         B, K, _ = u_seq.shape

#         h       = self.ctrl(u_seq)                    # (B,K,H)
#         v_raw   = self.vel_head(self.drift(h))        # (B,K,6)  velocity field

#         # ----- build Euler increments in *one* tensor ------------------
#         dt_exp  = dt_seq.unsqueeze(-1)                # (B,K,1)
#         incr    = v_raw * dt_exp                      # (B,K,6)

#         # zero increment for k = 0
#         incr[:, 0] = 0.0

#         # initial parameter @ k = 0
#         raw0    = self.param_head(h[:, 0])            # (B,6)

#         # cumulative sum → θ_k  (broadcast raw0)
#         raw_all = raw0.unsqueeze(1) + torch.cumsum(incr, dim=1)  # (B,K,6)

#         # ----- map to bounded ranges -----------------------------------
#         VTX_raw, VTX_mag, kdm_raw, VTL_raw, VTL_mag, kmt_raw = raw_all.chunk(6, -1)
#         VTX_max = 1e-4 + (2e-2 - 1e-4) * torch.sigmoid(VTX_mag)
#         VTL_max = 1e-5 + (2e-2 - 1e-5) * torch.sigmoid(VTL_mag)
#         kdm     = 1e-4 + (1e-2 - 1e-4) * torch.sigmoid(kdm_raw)
#         kmt     = 1e-6 + (1e-3 - 1e-6) * torch.sigmoid(kmt_raw)

#         out, params = integrate_three_state_with_gates_fixed(
#             build_x0_ext_on(x0), dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         return out if self.training else (out, params.detach())

# ###############################################################################
# # 3) Dilated Causal CNN (TCN)
# ###############################################################################
# class CNN_model_vectorized(nn.Module):
#     def __init__(self,
#                  in_u: int,
#                  hidden: int = 128,
#                  levels: int = 12,
#                  k_size: int = 2,
#                  dropout: float = 0.1):
#         super().__init__()
#         self.in_conv = nn.Conv1d(in_u, hidden, 1)
#         layers = []
#         for l in range(levels):
#             d   = 2 ** l
#             pad = (k_size - 1) * d
#             layers += [
#                 nn.Conv1d(hidden, hidden, k_size,
#                           dilation=d, padding=pad),
#                 nn.GroupNorm(1, hidden),
#                 nn.SiLU(),
#                 nn.Dropout(dropout)
#             ]
#         self.tcn  = nn.Sequential(*layers)
#         self.head = nn.Linear(hidden, 6)

#     # ------------------------------------------------------------------
#     def forward(
#         self,
#         x0:      torch.Tensor,
#         u_seq:   torch.Tensor,   # (B,K,U)
#         dna_raw: torch.Tensor,
#         dt_seq:  torch.Tensor,   # (B,K)
#         y_seq:   Optional[torch.Tensor] = None
#     ):
#         x = u_seq.transpose(1, 2)                    # (B,U,K)
#         x = self.in_conv(x)
#         x = self.tcn(x)[:, :, :-self.tcn[0].padding[0]]
#         x = x.transpose(1, 2)                        # (B,K,H)
#         raw = self.head(x)

#         VTX_raw, VTX_mag, kdm_raw, VTL_raw, VTL_mag, kmt_raw = raw.chunk(6, -1)
#         VTX_max = 1e-4 + (2e-2 - 1e-4) * torch.sigmoid(VTX_mag)
#         VTL_max = 1e-5 + (2e-2 - 1e-5) * torch.sigmoid(VTL_mag)
#         kdm     = 1e-4 + (1e-2 - 1e-4) * torch.sigmoid(kdm_raw)
#         kmt     = 1e-6 + (1e-3 - 1e-6) * torch.sigmoid(kmt_raw)


#         out, params = integrate_three_state_with_gates_fixed(
#             build_x0_ext_on(x0), dna_raw, dt_seq,
#             VTX_raw, VTX_max, kdm,
#             VTL_raw, VTL_max, kmt)

#         return out if self.training else (out, params.detach())


# # --------------- Closed-loop stacked-GRU with scripted step ------------------
# class GRU_model_latent_decay_simple_fb(nn.Module):
#     """
#     Closed-loop, single pass, N-layer GRU:
#       input at step k: [u_k, dna_k, dt_k, log1p(m_{k-1}), log1p(p*_{k-1})]
#       -> stacked GRUCells (num_layers)
#       -> θ_k = [λ, VTX_max, kdm, VTL_max, kmt]  (bounded)
#       -> ivtt_step() (TorchScript) -> y_k, fed into step k+1

#     DNA handling: uses dna_cum_total (constant per sequence) at all steps.
#     """
#     def __init__(self,
#                  in_u: int,
#                  hidden: int = 128,
#                  num_layers: int = 2,
#                  dropout: float = 0.2):
#         super().__init__()
#         assert num_layers >= 1
#         self.hidden = hidden
#         self.num_layers = num_layers

#         # GRU input per step: u_k + dna_k + dt_k + [log m_{k-1}, log p*_{k-1}]
#         in_dim = in_u + 1 + 1 + 2

#         # stacked GRUCells
#         cells = [nn.GRUCell(in_dim, hidden)]
#         cells += [nn.GRUCell(hidden, hidden) for _ in range(num_layers - 1)]
#         self.cells = nn.ModuleList(cells)
#         self.dropout = nn.Dropout(dropout)

#         # small bottleneck + head (5 params)
#         self.bottle = nn.Sequential(
#             nn.Linear(hidden, 64), nn.SiLU(),
#             nn.Linear(64, 32),     nn.SiLU()
#         )
#         self.head1 = nn.Linear(hidden, 5)  # [λ_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw]

#         # recurrent init
#         for c in self.cells:
#             nn.init.orthogonal_(c.weight_hh)
#             nn.init.xavier_uniform_(c.weight_ih)
#             nn.init.zeros_(c.bias_hh)
#             nn.init.zeros_(c.bias_ih)

#     def forward(self,
#                 x0:      torch.Tensor,   # (B,2)  [m0, p*0]
#                 u_seq:   torch.Tensor,   # (B,K,U)
#                 dna_raw: torch.Tensor,   # (B,K,1)
#                 dt_seq:  torch.Tensor,   # (B,K)
#                 y_seq:   torch.Tensor | None = None):

#         B, K, U = u_seq.shape
#         device = u_seq.device

#         # outputs
#         m_out  = torch.empty(B, K, 1, device=device)
#         p_out  = torch.empty_like(m_out)
#         pm_out = torch.empty_like(m_out)

#         # diagnostics
#         VTX_seq = torch.empty_like(m_out)
#         VTL_seq = torch.empty_like(m_out)
#         kdm_seq = torch.empty_like(m_out)
#         kmt_seq = torch.empty_like(m_out)
#         R_seq   = torch.empty_like(m_out)
#         lam_seq = torch.empty_like(m_out)

#         # ODE states
#         m_prev  = x0[:, 0:1]
#         pm_prev = x0[:, 1:2]
#         p_prev  = torch.zeros_like(m_prev)
#         R_prev  = torch.ones_like(m_prev)

#         # constant DNA per sequence (matches your integrator)
#         dna_cum_total = torch.cumsum(dna_raw, dim=1)[:, -1, :]  # (B,1)

#         # hidden states
#         hs = [torch.zeros(B, self.hidden, device=device) for _ in range(self.num_layers)]

#         for k in range(K):
#             dt_k  = dt_seq[:, k:k+1]    # (B,1)
#             u_k   = u_seq[:, k]         # (B,U)
            
#             # GRU input includes previous ODE state
#             feat_k = torch.cat(
#                 [u_k, torch.log1p(m_prev), torch.log1p(p_prev), torch.log1p(pm_prev), R_prev],
#                 dim=-1
#             )  # (B, U+1+1+2)

#             # stacked GRUCells
#             x = feat_k
#             for li, cell in enumerate(self.cells):
#                 hs[li] = cell(x, hs[li])
#                 x = self.dropout(hs[li]) if self.training else hs[li]
#             h = x  # (B, hidden)

#             # head → bounded parameters for this step
#             z   = self.bottle(h)
#             raw = self.head1(z)
#             lam_raw, VTX_mag, kdm_raw, VTL_mag, kmt_raw = raw.split(1, dim=-1)
    
#             lam_k = gamma(lam_raw, 1e-6, 0.0005)
#             VTXmax = gamma(VTX_mag, 1e-4, 0.2)
#             VTLmax = gamma(VTL_mag, 1e-5, 0.1)
#             kdm = gamma(kdm_raw, 1e-4, 1e-2)
#             kmt = gamma(kmt_raw, 1e-5, 0.00015)
            

#             # ---- Call the scripted solver for one step ----
#             m_curr, p_curr, pm_curr, R_curr = ivtt_step(
#                 m_prev, p_prev, pm_prev, R_prev,
#                 dt_k, dna_cum_total,
#                 lam_k, VTXmax, kdm, VTLmax, kmt
#             )

#             # store (use unsqueeze to match (B,1,1) slices)
#             m_out[:,  k:k+1, :] = m_curr.unsqueeze(1)
#             p_out[:,  k:k+1, :] = p_curr.unsqueeze(1)
#             pm_out[:, k:k+1, :] = pm_curr.unsqueeze(1)

#             VTX_seq[:, k:k+1, :] = VTXmax.unsqueeze(1)
#             kdm_seq[:, k:k+1, :] = kdm.unsqueeze(1)
#             VTL_seq[:, k:k+1, :] = VTLmax.unsqueeze(1)
#             kmt_seq[:, k:k+1, :] = kmt.unsqueeze(1)
#             R_seq[:,   k:k+1, :] = R_curr.unsqueeze(1)
#             lam_seq[:, k:k+1, :] = lam_k.unsqueeze(1)

#             # roll
#             m_prev, p_prev, pm_prev, R_prev = m_curr, p_curr, pm_curr, R_curr

#         out    = torch.cat([m_out, p_out, pm_out], dim=-1)  # (B,K,3)
#         params = torch.cat([VTX_seq, kdm_seq, VTL_seq, kmt_seq, R_seq, lam_seq], dim=-1)  # (B,K,6)

        # return (out, params.detach()) if self.training else (out, params.detach())
    
